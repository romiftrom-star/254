import math
from fx import *


def ik(hip, foot, l1, l2, bend):
    dx, dy = foot[0] - hip[0], foot[1] - hip[1]
    d = min(math.hypot(dx, dy), l1 + l2 - 0.01)
    d = max(d, 0.5)
    a = math.atan2(dy, dx)
    A = math.acos(clamp((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1))
    ang = a - bend * A
    return (hip[0] + l1 * math.cos(ang), hip[1] + l1 * math.sin(ang))


def _draw(cv, prims, off=(0, 0), col=None, glow=0.0):
    for p in prims:
        k = p[0]
        if k == 'l':
            cv.line((p[1][0] + off[0], p[1][1] + off[1]), (p[2][0] + off[0], p[2][1] + off[1]), p[3], col or p[4], glow)
        elif k == 'c':
            cv.circ(p[1] + off[0], p[2] + off[1], p[3], col or p[4], glow)
        elif k == 'p':
            cv.poly([(x + off[0], y + off[1]) for x, y in p[1]], col or p[2], glow)


def draw_prims(cv, prims, rim=(1, .7, .4), light=(-1.6, -1.0), rimg=0.0):
    """rim-lit silhouette: first offset pass in rim color then the body"""
    if rim is not None:
        _draw(cv, prims, off=light, col=rim, glow=rimg)
    _draw(cv, prims)


def walker(h, x, gy, phase, face=1, kind='woman', cols=None, lean=0.05, stride=0.30, lift=0.10, slope=0.0,
           pack=None, bob=0.012, still=False, arm_up=0.0, bendover=0.0):
    """return list of primitives of a walking person; slope = dy/dx of ground (negative: uphill to right)"""
    cols = cols or {}
    skin = cols.get('skin', (0.55, 0.38, 0.28))
    top = cols.get('top', (0.10, 0.12, 0.16))
    bot = cols.get('bot', (0.07, 0.07, 0.09))
    scarf = cols.get('scarf', (0.12, 0.10, 0.14))
    far = lambda c: tuple(v * 0.6 for v in c)
    f = face
    ph = 2 * math.pi * phase
    bobv = 0 if still else abs(math.sin(ph)) * bob * h
    hipy = gy - h * 0.50 - bobv
    hip = (x + f * lean * h * 0.15, hipy)
    L = h * 0.31
    sh_ang = lean + bendover
    sho = (hip[0] + f * math.sin(sh_ang) * L, hip[1] - math.cos(sh_ang) * L)
    head_r = h * 0.062
    headc = (sho[0] + f * math.sin(sh_ang + 0.05) * h * 0.075, sho[1] - math.cos(sh_ang) * h * 0.085)
    prims = []
    l1 = l2 = h * 0.255
    feet = []
    for i, ofs in enumerate((0.0, 0.5)):
        pp = ph + ofs * 2 * math.pi
        fx = x + f * math.sin(pp) * stride * h * (0 if still else 1)
        lf = 0 if still else max(0, math.cos(pp)) * lift * h
        fy = gy + slope * (fx - x) - lf
        feet.append((fx, fy))
    knees = [ik(hip, feet[i], l1, l2, f) for i in range(2)]
    legw = h * 0.075
    # far leg
    order = [1, 0] if math.sin(ph) >= 0 else [0, 1]
    arms_ph = [math.sin(ph + math.pi), math.sin(ph)]
    aL = h * 0.16

    def arm(i, shade):
        sw = (0 if still else arms_ph[i] * 0.55) + (arm_up if i == 0 else arm_up * 0.3)
        a1 = sw * f
        elb = (sho[0] + math.sin(a1) * aL, sho[1] + math.cos(a1) * aL)
        a2 = a1 + f * (0.5 + 0.4 * max(0, -arms_ph[i]) if not still else 0.35)
        hnd = (elb[0] + math.sin(a2) * aL * 0.95, elb[1] + math.cos(a2) * aL * 0.95)
        c = far(top) if shade else top
        prims.append(('l', sho, elb, h * 0.05, c))
        prims.append(('l', elb, hnd, h * 0.043, c))
        prims.append(('c', hnd[0], hnd[1], h * 0.03, far(skin) if shade else skin))
        return hnd

    arm(1, True)
    lg = far(bot)
    # far leg
    i = order[0]
    prims.append(('l', hip, knees[i], legw, lg))
    prims.append(('l', knees[i], feet[i], legw * 0.85, lg))
    prims.append(('l', feet[i], (feet[i][0] + f * h * 0.07, feet[i][1]), h * 0.04, lg))
    packpos = None
    # backpack
    if pack:
        pw, ph_ = pack.get('w', h * 0.17), pack.get('h', h * 0.25)
        bxc = sho[0] - f * h * 0.10 + f * math.sin(sh_ang) * (-h * 0.08)
        byc = sho[1] + h * 0.14
        packpos = (bxc, byc)
        prims.append(('p', [(bxc - pw / 2, byc - ph_ / 2), (bxc + pw / 2, byc - ph_ / 2), (bxc + pw / 2 + 2, byc + ph_ / 2),
                            (bxc - pw / 2 - 2, byc + ph_ / 2)], pack.get('col', (0.35, 0.18, 0.1))))
        prims.append(('l', (bxc - pw / 2 + 2, byc - ph_ / 2 + 2), (bxc + pw / 2 - 2, byc - ph_ / 2 + 2), 3, tuple(v * 1.3 for v in pack.get('col', (0.35, 0.18, 0.1)))))
    # torso
    tw = h * 0.085
    if kind == 'woman':
        # long coat to knees
        hem = (hip[0] + f * 0 + h * 0.0, hip[1] + h * 0.22)
        prims.append(('p', [(sho[0] - tw, sho[1]), (sho[0] + tw, sho[1]), (hem[0] + tw * 1.25 + f * 2, hem[1]), (hem[0] - tw * 1.25 + f * 2, hem[1])], top))
        prims.append(('l', (sho[0] + f * tw * .2, sho[1] + h * .05), (hem[0] + f * 2, hem[1] - 2), 2, tuple(v * 1.5 for v in top)))
        # hijab shawl over shoulders
        prims.append(('p', [(headc[0] - head_r * 1.15, headc[1]), (headc[0] + head_r * 1.15, headc[1]),
                            (sho[0] + tw * 1.15, sho[1] + h * 0.10), (sho[0], sho[1] + h * 0.17), (sho[0] - tw * 1.15, sho[1] + h * 0.10)], scarf))
    else:
        prims.append(('p', [(sho[0] - tw, sho[1]), (sho[0] + tw, sho[1]), (hip[0] + tw * 0.95, hip[1] + h * 0.04), (hip[0] - tw * 0.95, hip[1] + h * 0.04)], top))
        prims.append(('l', sho, (sho[0] + f * h * .02, sho[1] - h * .02), 3, skin))
    # near leg
    i = order[1]
    prims.append(('l', hip, knees[i], legw, bot))
    prims.append(('l', knees[i], feet[i], legw * 0.85, bot))
    prims.append(('l', feet[i], (feet[i][0] + f * h * 0.075, feet[i][1]), h * 0.042, tuple(v * 0.7 for v in bot)))
    # neck + head
    prims.append(('l', sho, headc, h * 0.04, skin))
    if kind == 'woman':
        prims.append(('c', headc[0], headc[1], head_r * 1.18, scarf))
        # face opening
        prims.append(('c', headc[0] + f * head_r * 0.45, headc[1] + head_r * 0.08, head_r * 0.62, skin))
        prims.append(('c', headc[0] - f * head_r * 0.2, headc[1], head_r * 1.0, scarf))
    else:
        prims.append(('c', headc[0], headc[1], head_r, skin))
        prims.append(('c', headc[0] - f * head_r * 0.15, headc[1] - head_r * 0.28, head_r * 0.92, (0.04, 0.03, 0.03)))
        prims.append(('c', headc[0] + f * head_r * 0.45, headc[1] + head_r * 0.12, head_r * 0.55, skin))
    arm(0, False)
    return prims, dict(sho=sho, hip=hip, head=headc, feet=feet, pack=packpos)


def old_man_sitting(h, x, gy, t, look_up=0.0, glass=True, cols=None):
    """seated old farmer in profile facing right: cap, vest, tea glass"""
    prims = []
    skin = (0.45, 0.30, 0.22)
    shirt = (0.30, 0.27, 0.22)
    vest = (0.10, 0.09, 0.09)
    pants = (0.12, 0.10, 0.09)
    hip = (x, gy - h * 0.10)
    breath = math.sin(t * 1.6) * 0.8
    sho = (hip[0] + h * 0.04, hip[1] - h * 0.40 + breath)
    knee = (x + h * 0.38, gy - h * 0.34)
    foot = (x + h * 0.62, gy - 1)
    prims.append(('l', hip, knee, h * 0.12, pants))
    prims.append(('l', knee, foot, h * 0.10, pants))
    prims.append(('l', foot, (foot[0] + h * 0.1, foot[1]), h * 0.05, (0.05, 0.04, 0.04)))
    prims.append(('p', [(sho[0] - h * 0.11, sho[1]), (sho[0] + h * 0.09, sho[1] + 2), (hip[0] + h * 0.12, hip[1] + h * 0.05), (hip[0] - h * 0.13, hip[1] + h * 0.07)], vest))
    hd = (sho[0] + h * 0.06 + look_up * h * 0.01, sho[1] - h * 0.13 - look_up * h * 0.01)
    prims.append(('l', sho, hd, h * 0.06, skin))
    r = h * 0.095
    prims.append(('c', hd[0], hd[1], r, skin))
    # cap
    prims.append(('p', [(hd[0] - r * 1.05, hd[1] - r * 0.1), (hd[0] + r * 1.1, hd[1] - r * 0.25), (hd[0] + r * 0.8, hd[1] - r * 1.0),
                        (hd[0] - r * 0.3, hd[1] - r * 1.15), (hd[0] - r * 1.0, hd[1] - r * 0.6)], (0.16, 0.14, 0.13)))
    prims.append(('l', (hd[0] + r * 0.2, hd[1] - r * 0.28), (hd[0] + r * 1.25, hd[1] - r * 0.22), 3, (0.12, 0.1, 0.1)))
    # white beard hint
    prims.append(('c', hd[0] + r * 0.35, hd[1] + r * 0.62, r * 0.45, (0.55, 0.52, 0.5)))
    # arm to glass
    elb = (sho[0] + h * 0.11, sho[1] + h * 0.17)
    hand = (hd[0] + h * 0.05 + (1 - look_up) * h * 0.12, hd[1] + h * 0.17 - (1 - look_up) * h * 0.02 - (1 - look_up) * h * 0.0)
    hand = (sho[0] + h * 0.30, sho[1] + h * 0.12 - math.sin(t * 0.7) * 2)
    prims.append(('l', sho, elb, h * 0.065, shirt))
    prims.append(('l', elb, hand, h * 0.055, shirt))
    prims.append(('c', hand[0], hand[1], h * 0.04, skin))
    if glass:
        gx, gy2 = hand[0] + h * 0.015, hand[1] - h * 0.04
        prims.append(('p', [(gx - 5, gy2 - 6), (gx + 5, gy2 - 6), (gx + 3, gy2 + 8), (gx - 3, gy2 + 8)], (0.75, 0.35, 0.1)))
    return prims, dict(glass=(hand[0], hand[1] - h * 0.10), head=hd)
