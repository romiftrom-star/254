import math
import numpy as np
from fx import *
from fx import _XX, _YY
from chars import *

GOLD = (1.0, 0.78, 0.35)
_cache = {}


def vgrad(stops):
    ys = np.linspace(0, 1, H)
    col = np.stack([np.interp(ys, [s[0] for s in stops], [s[1][ch] for s in stops]) for ch in range(3)], 1).astype(np.float32)
    return np.repeat(col[:, None, :], W, 1)


def cached(k, f):
    if k not in _cache:
        _cache[k] = f()
    return _cache[k]


def motes(cv, t, n, seed, color, speed=12, size=1.6, up=True, gl=0.9, spread=1.0):
    r = np.random.default_rng(seed)
    x0 = r.random(n) * W
    y0 = r.random(n) * H
    vx = (r.random(n) - .5) * speed
    vy = -(0.4 + r.random(n)) * speed * (1 if up else -1)
    ph = r.random(n) * 6.28
    for i in range(n):
        x = (x0[i] + vx[i] * t + math.sin(t * .7 + ph[i]) * 10) % W
        y = (y0[i] + vy[i] * t) % H
        a = 0.4 + 0.6 * math.sin(t * 1.3 + ph[i]) ** 2
        cv.circ(x, y, size * (0.6 + r.random() * 0.8) * (0.7 + a * 0.5), tuple(v * a for v in color), gl)


# ------------------------------------------------------------ roots
SURF = 120


def _roots():
    r = np.random.default_rng(11)
    segs = []

    def grow(x, y, ang, length, depth, cum):
        n = max(3, int(length / 12))
        step = length / n
        for i in range(n):
            ang += r.normal(0, 0.16)
            if depth > 0:
                ang += (0 - ang) * 0.04 * 0  # keep
            nx, ny = x + step * math.sin(ang), y + step * math.cos(ang)
            if depth > 0 and ny < SURF + 6:
                ang = abs(ang) * 0.3
                nx, ny = x + step * math.sin(ang), y + step * math.cos(ang) * 0.2 + 2
            segs.append((x, y, nx, ny, depth, cum))
            cum += step
            x, y = nx, ny
            if depth < 4 and i > 1 and r.random() < (0.36 if depth < 2 else 0.22):
                side = r.choice([-1, 1])
                grow(x, y, ang + side * r.uniform(0.8, 1.25), length * r.uniform(0.34, 0.5), depth + 1, cum)

    grow(W / 2, SURF + 6, 0.0, 560, 0, 0.0)
    # root crown thicker laterals
    for s in (-1, 1):
        grow(W / 2, SURF + 12, s * 1.1, 200, 1, 40)
    mx = max(s[5] for s in segs) + 40
    return segs, mx


def roots(t, dur=35.0):
    segs, mx = cached('roots', _roots)
    p = clamp(t / dur)
    g = sm(p * 1.05)
    cam = lerp(0, 380, sm(seg(p, 0.05, 0.98)))
    # soil
    n = ncrop('soil', 40, cam * 0.9)
    n2 = ncrop('fine', 300, cam * 1.1)
    soil = np.zeros((H, W, 3), np.float32)
    k = (0.35 + 1.1 * n) * (0.8 + 0.5 * n2)
    soil[..., 0] = 0.20 * k
    soil[..., 1] = 0.11 * k
    soil[..., 2] = 0.06 * k
    pebbles = np.clip((n2 - 0.70) * 9, 0, 1)[..., None] * np.array([0.30, 0.22, 0.17], np.float32)
    soil += pebbles
    # dark depth gradient
    soil *= (1.0 - 0.45 * np.clip((YN * H + cam - SURF) / 600, 0, 1))[..., None]
    # sky strip above surface
    sy = SURF - cam
    if sy > 0:
        sky = vgrad([(0, (0.04, 0.06, 0.12)), (max(sy / H, 0.01) * 0.9, (0.55, 0.30, 0.18)), (max(sy / H, 0.02), (0.08, 0.06, 0.05)), (1, (0.08, 0.06, 0.05))])
        mask = (_YY < sy)[..., None]
        soil = np.where(mask, sky, soil)
    cv = Cv(soil)
    if sy > -10:
        # grass silhouette
        for i in range(0, W, 5):
            hh = 14 + 12 * math.sin(i * .37) + 7 * math.sin(i * 1.9)
            sw = math.sin(t * 1.2 + i * .05) * 2
            cv.d.line([(i, sy + 2), (i + sw, sy - hh)], fill=(6, 8, 6), width=2)
        cv.d.line([(0, sy + 1), (W, sy + 1)], fill=(40, 28, 18), width=3)
    # seed
    sx, sy2 = W / 2, SURF + 4 - cam
    seedr = 9 * (1 - 0.5 * sm(seg(p, 0.0, 0.25)))
    cv.ell(sx, sy2, seedr * 1.3, seedr, (0.55, 0.35, 0.15), 0.5)
    # roots
    Lg = g * mx
    for (x0, y0, x1, y1, dp, cum) in segs:
        if cum >= Lg:
            continue
        ln = math.hypot(x1 - x0, y1 - y0)
        f = clamp((Lg - cum) / max(ln, 1e-3))
        ex, ey = lerp(x0, x1, f), lerp(y0, y1, f)
        age = clamp((Lg - cum) / 220)
        w = [5, 3.2, 2.2, 1.6, 1.2][dp] * (0.5 + 0.5 * age)
        col = lerpc((1.0, 0.95, 0.75), (0.95, 0.62, 0.25), clamp(dp / 4 + (1 - age) * 0.0))
        cv.line((x0, y0 - cam), (ex, ey - cam), w, col, 0.35)
        if f < 1.0:
            cv.circ(ex, ey - cam, 3.2, (1, 1, 0.9), 0.8)
    for i in range(1):
        motes(cv, t, 50, 3, (1.0, 0.7, 0.35), speed=6, size=1.2)
    # day counter
    day = 1 + int(13 * g)
    text(cv, 'روز ' + fa(day), 130, 345, 34, GOLD, 0.95, glow=0.7)
    # progress ticks
    for i, d in enumerate((1, 5, 9, 14)):
        a = 0.9 if day >= d else 0.25
        cv.circ(70 + i * 22, 372, 4, (1, .8, .4) if day >= d else (.3, .25, .2), 0.6 if day >= d else 0)
    a = cv.out()
    return a


# ------------------------------------------------------------ farmer
def farmer(t, dur=30.0):
    p = clamp(t / dur)
    hz = int(H * 0.60)
    sun = (W * 0.66, hz - 8)
    sky = cached('f_sky', lambda: vgrad([(0, (0.05, 0.08, 0.20)), (0.30, (0.45, 0.22, 0.34)), (0.50, (0.95, 0.50, 0.22)), (0.60, (1.0, 0.72, 0.35)), (1, (1, .7, .3))]))
    a = sky.copy()
    d = np.hypot(_XX - sun[0], _YY - sun[1])
    ang = np.arctan2(_YY - sun[1], _XX - sun[0])
    rays = (0.5 + 0.5 * np.sin(ang * 19 + 2.5 * np.sin(ang * 5 + t * 0.15) + t * 0.1)) ** 3
    glow = np.exp(-d / 150)[..., None]
    a += glow * np.array([1.0, 0.55, 0.2], np.float32) * 0.9
    a += (rays * np.exp(-d / 420))[..., None] * np.array([1.0, 0.6, 0.25], np.float32) * 0.28
    # clouds
    cl = ncrop('cloud', t * 6, 20)
    cm = np.clip((cl - 0.52) * 3.0, 0, 1) * np.clip(1 - YN / 0.55, 0, 1)
    a = a * (1 - cm[..., None] * 0.5) + cm[..., None] * np.array([0.9, 0.38, 0.30], np.float32) * 0.35 * (1 + glow * 1.2)
    cv0 = Cv(a)
    cv0.circ(sun[0], sun[1], 30, (1.0, 0.95, 0.75), 1.0)
    # far mountains
    for li, (col, amp, base, ph) in enumerate([((0.30, 0.17, 0.30), 26, hz - 18, 1.0), ((0.20, 0.11, 0.22), 20, hz - 4, 2.7)]):
        pts = [(x, base - amp * (0.5 + 0.5 * math.sin(x * 0.006 + ph) * math.sin(x * 0.017 + ph * 2) + 0.15 * math.sin(x * 0.05))) for x in range(0, W + 8, 8)]
        cv0.poly(pts + [(W, hz + 2), (0, hz + 2)], col)
    a = cv0.out(0.8)
    # field perspective
    z = 1.0 / np.maximum((YN * H - hz) / 60.0, 0.02)
    u = (_XX - sun[0]) / W * z
    row = 0.5 + 0.5 * np.sin(u * 40 + 1.5 * np.sin(z * 2.5 + t * 0.9) + z * 2)
    row = 0.5 + (row - 0.5) * np.clip((YN * H - hz) / 70.0, 0, 1)
    fy = (_YY > hz)
    fcol = np.zeros((H, W, 3), np.float32)
    lightf = np.exp(-np.abs(_XX - sun[0]) / 420)
    near = np.clip((YN * H - hz) / (H - hz), 0, 1)
    fcol[..., 0] = (0.22 + 0.55 * row) * (0.35 + 0.65 * lightf)
    fcol[..., 1] = (0.14 + 0.38 * row) * (0.35 + 0.65 * lightf)
    fcol[..., 2] = (0.05 + 0.10 * row)
    fcol *= (1 - 0.72 * near)[..., None] ** 1.0
    hazef = np.exp(-(near * 7))[..., None] * np.array([0.9, 0.5, 0.25], np.float32) * 0.45
    fcol += hazef
    a = np.where(fy[..., None], fcol, a)
    cv = Cv(a)
    # birds
    for i in range(4):
        bx = (150 + i * 120 + t * 14) % (W + 100) - 50
        by = 90 + i * 14 + math.sin(t + i) * 6
        fl = math.sin(t * 6 + i) * 5
        cv.d.line([(bx - 8, by - fl), (bx, by), (bx + 8, by - fl)], fill=(20, 12, 18), width=2)
    # man sitting
    gy = int(H * 0.88)
    look = seg(p, 0.55, 0.75) * (1 - seg(p, 0.9, 1.0) * 0.5)
    prims, info = old_man_sitting(168, 250, gy, t, look_up=look)
    draw_prims(cv, prims, rim=(1.0, 0.62, 0.28), light=(2.0, -1.2), rimg=0.0)
    # steam
    gx, gyy = info['glass']
    for i in range(14):
        ph = (t * 0.55 + i / 14) % 1.0
        sx = gx + math.sin(ph * 7 + i) * (3 + ph * 8)
        sy = gyy - ph * 46
        cv.circ(sx, sy, 2 + ph * 5, (0.8 * (1 - ph), 0.7 * (1 - ph), 0.6 * (1 - ph)), 0.35)
    # foreground wheat blades
    for i in range(0, W, 9):
        hh = 36 + 30 * (0.5 + 0.5 * math.sin(i * 1.3))
        sw = math.sin(t * 1.4 + i * 0.07) * 5 + 3
        cv.d.line([(i, H + 2), (i + sw * 0.5, H - hh * 0.5), (i + sw, H - hh)], fill=(14, 9, 6), width=3)
        cv.d.line([(i + 2, H + 2), (i + 2 + sw * 0.5, H - hh * 0.5), (i + 3 + sw, H - hh)], fill=(40, 22, 8), width=1)
    out = cv.out(1.0)
    return out


# ------------------------------------------------------------ sprout + radio
def sprout(t, dur=20.0):
    p = clamp(t / dur)
    bg = cached('sp_bg', lambda: vgrad([(0, (0.10, 0.07, 0.06)), (0.55, (0.28, 0.17, 0.09)), (0.62, (0.20, 0.11, 0.06)), (1, (0.06, 0.03, 0.02))]))
    a = bg.copy()
    # bokeh
    r = np.random.default_rng(9)
    cv = Cv(a)
    for i in range(26):
        bx, by, br = r.random() * W, r.random() * H * 0.55, 8 + r.random() * 26
        al = 0.12 + 0.1 * math.sin(t * .8 + i)
        cv.circ(bx, by, br, (1.0 * al * 3, 0.6 * al * 3, 0.25 * al * 3), 0.25)
    # wooden table
    n = ncrop('fine', 0, 0)
    tab = np.zeros((H, W, 3), np.float32)
    streak = 0.5 + 0.5 * np.sin(_XX * 0.03 + n * 14)
    tab[..., 0] = 0.30 * (0.5 + streak * 0.6)
    tab[..., 1] = 0.16 * (0.5 + streak * 0.6)
    tab[..., 2] = 0.07 * (0.5 + streak * 0.6)
    tab *= (1.1 - 0.7 * np.clip((YN - 0.62) / 0.4, 0, 1))[..., None]
    arr = np.asarray(cv.im).astype(np.float32) / 255
    mk = (_YY > H * 0.62)[..., None]
    arr = np.where(mk, tab, arr)
    cv2 = Cv(arr)
    cv2.gl = cv.gl
    cv2.gd = ImageDraw.Draw(cv2.gl)
    cv = cv2
    ty = H * 0.62
    # soil mound
    mx, my = W * 0.30, ty
    pts = [(mx + math.cos(a_) * (150 - 40 * abs(math.sin(a_))), my - math.sin(a_) * 46) for a_ in np.linspace(0, math.pi, 30)]
    cv.poly(pts, (0.14, 0.08, 0.05))
    rr = np.random.default_rng(3)
    for i in range(80):
        px_, py_ = mx + (rr.random() - .5) * 270, my - rr.random() * 38
        if ((px_ - mx) / 150) ** 2 + ((my - py_) / 46) ** 2 < 0.9:
            cv.circ(px_, py_, 1.5 + rr.random() * 3, (0.22 * rr.random() + .1, 0.12, 0.07))
    # sprout
    g = sm(seg(p, 0.12, 0.72))
    if g > 0.01:
        hgt = 175 * g
        pts = []
        for i in range(18):
            u = i / 17
            pts.append((mx + math.sin(u * 2.2 + 0.4) * 10 * g + u * u * 18 * g, my - 20 - u * hgt))
        for i in range(17):
            cv.line(pts[i], pts[i + 1], 5 - 2 * i / 17, (0.45, 0.85, 0.25), 0.35)
        tip = pts[-1]
        lf = sm(seg(p, 0.45, 0.85))
        for sgn in (-1, 1):
            L = 62 * lf + 4
            ang = math.radians(-12 + sgn * (10 + 60 * (1 - lf)))
            ex, ey = tip[0] + sgn * math.cos(ang) * L, tip[1] - math.sin(ang) * L * 0.5 + 8 * (1 - lf) - (1 - lf) * 10
            mxp, myp = (tip[0] + ex) / 2, min(tip[1], ey) - 14 * lf - 6
            leaf = [tip, (mxp, myp - 5 * lf), (ex, ey), (mxp, myp + 14 * lf + 3)]
            cv.poly(leaf, (0.38, 0.80, 0.22), 0.5)
            cv.line(tip, (ex, ey), 1.6, (0.8, 1.0, 0.5), 0.3)
    # radio
    rx, ry = W * 0.73, ty - 100
    bw, bh = 210, 130
    cv.rect(rx - bw / 2 - 3, ry - 3, rx + bw / 2 + 3, ry + bh + 3, (0.05, 0.03, 0.02))
    for i in range(int(bh)):
        sh = 0.30 + 0.15 * math.sin(i * 0.4 + 1)
        cv.d.line([(rx - bw / 2, ry + i), (rx + bw / 2, ry + i)], fill=c8((sh * 0.8, sh * 0.42, sh * 0.2)))
    # grille
    for i in range(9):
        cv.d.line([(rx - bw / 2 + 14, ry + 16 + i * 8), (rx - 8, ry + 16 + i * 8)], fill=(25, 14, 8), width=3)
    talk = seg(p, 0.55, 1.0)
    pul = 0.6 + 0.4 * math.sin(t * 9) * talk if talk > 0 else 0.35
    cv.rect(rx + 6, ry + 14, rx + bw / 2 - 12, ry + 52, (0.95 * pul, 0.65 * pul, 0.2 * pul), 0.9)
    cv.d.line([(rx + 10, ry + 33), (rx + bw / 2 - 16, ry + 33)], fill=(60, 30, 10), width=1)
    cv.d.line([(rx + 18 + 40 * talk, ry + 16), (rx + 18 + 40 * talk, ry + 50)], fill=(120, 20, 10), width=2)
    for k in range(2):
        cv.circ(rx + 34 + k * 56, ry + 90, 15, (0.18, 0.1, 0.07))
        cv.line((rx + 34 + k * 56, ry + 90), (rx + 34 + k * 56 + 8, ry + 84), 2, (0.9, 0.7, 0.4))
    # antenna
    ant = (rx - 70, ry - 120 * clamp(seg(p, 0.0, 0.1) + 0.3))
    cv.line((rx - 70, ry), ant, 2, (0.7, 0.7, 0.75), 0.2)
    cv.circ(ant[0], ant[1], 4, (1, 0.5, 0.3), 0.8)
    # waves answering
    for i in range(6):
        ph = ((t * 0.5 + i / 6) % 1.0) if talk > 0 else 1.0
        if talk > 0:
            rad = 20 + ph * 330
            al = (1 - ph) * talk
            cv.ell(ant[0], ant[1], rad, rad * 0.55, None, 0.6 * al, outline=(1.0 * al, 0.7 * al, 0.35 * al), w=2)
    # foreground blur bokeh
    for i in range(6):
        bx = (i * 190 + 60) % W
        by = H - 30 + math.sin(t * .4 + i) * 6
        cv.circ(bx, by, 30 + i * 4, (0.07, 0.04, 0.02), 0.0)
    motes(cv, t, 30, 8, (1, .7, .4), speed=5, size=1.4)
    return cv.out()


# ------------------------------------------------------------ ayah card
def ayah_card(t, dur, mask, ref, accent=GOLD, sub=None, wfrac=0.62):
    p = clamp(t / dur)
    bgc = cached('ay_bg', lambda: vgrad([(0, (0.01, 0.02, 0.04)), (0.5, (0.03, 0.05, 0.08)), (1, (0.01, 0.01, 0.02))]))
    n = ncrop('cloud', t * 5, 40)
    a = bgc + (n[..., None] ** 2) * np.array([0.10, 0.07, 0.03], np.float32) * (0.5 + 0.5 * sm(seg(p, 0, 0.3)))
    cv = Cv(a)
    # light beam rings
    rad = 70 + 80 * sm(p)
    cv.ell(W / 2, H * 0.48, rad * 2.2, rad * 0.8, None, 0.35, outline=tuple(v * 0.25 for v in accent), w=2)
    al = sm(seg(p, 0.08, 0.35)) * (1 - sm(seg(p, 0.92, 1.0)))
    sc = (W * wfrac) / mask.width
    m = mask.resize((int(mask.width * sc), int(mask.height * sc)), Image.LANCZOS)
    mask_put(cv, m, W / 2, H * 0.46, (1.0, 0.92, 0.7), al, glow=1.4)
    text(cv, ref, W / 2, H * 0.46 + m.height / 2 + 34, 20, accent, al * 0.9, 'r', glow=0.5)
    if sub:
        text(cv, sub, W / 2, H * 0.88, 22, (0.9, 0.9, 0.95), al * 0.8, 'r')
    motes(cv, t, 70, 21, accent, speed=10, size=1.5)
    return cv.out()
