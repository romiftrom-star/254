import asyncio, edge_tts, json, os, subprocess, sys
sys.path.insert(0,'.')
from script import *
import imageio_ffmpeg
FF=imageio_ffmpeg.get_ffmpeg_exe()
D='/tmp/w/tts'; os.makedirs(D,exist_ok=True)
async def one(id_,text,voice,rate='-6%',pitch='+0Hz'):
    p=f'{D}/{id_}.mp3'
    if os.path.exists(p): return
    for _ in range(3):
        try:
            await edge_tts.Communicate(text,voice,rate=rate,pitch=pitch).save(p); return
        except Exception as e: print('retry',id_,e)
async def main():
    for id_,st,tx,v in NARR: await one(id_,tx,v)
    for i,ph in enumerate(PHRASES): await one(f'w{i:02d}',ph,'fa-IR-DilaraNeural' if i%2 else 'fa-IR-FaridNeural',rate='-15%')
asyncio.run(main())
def dur(p):
    r=subprocess.run([FF,'-i',p],capture_output=True,text=True).stderr
    import re; m=re.search(r'Duration: (\d+):(\d+):([\d.]+)',r); return int(m[1])*3600+int(m[2])*60+float(m[3])
def chunks(text,a,d,who,maxw=8):
    ws=text.split(' '); n=max(1,round(len(ws)/maxw)); per=-(-len(ws)//n)
    out=[]; tot=len(ws); pos=0
    for k in range(0,len(ws),per):
        seg=ws[k:k+per]; s=a+d*k/tot; e=a+d*(k+len(seg))/tot
        out.append([round(s,2),round(e-0.05,2),' '.join(seg),who])
    return out
subs=[]; info={}
for id_,st,tx,v in NARR:
    d=dur(f'{D}/{id_}.mp3'); info[id_]=d
    subs+=chunks(tx,st,d,'narr')
for id_,f,a,b,st,tx in MASTER:
    subs+=chunks(tx,st,b-a,'master')
subs.sort(key=lambda x:x[0])
json.dump(subs,open('/tmp/w/subs.json','w'),ensure_ascii=False)
json.dump(info,open('/tmp/w/tts_dur.json','w'))
print(len(subs),info)
