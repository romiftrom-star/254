import sys,time
from render import *
ts=[float(x) for x in sys.argv[2:]]
ims=[]
t0=time.time()
for t in ts:
    im=frame(int(t*FPS)).crop((0,96,1280,624)).resize((640,264)); ims.append(im)
print('per frame',(time.time()-t0)/len(ts))
sh=Image.new('RGB',(1280,264*((len(ims)+1)//2)))
for i,im in enumerate(ims): sh.paste(im,((i%2)*640,(i//2)*264))
sh.save(sys.argv[1])
