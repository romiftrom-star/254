import math
import numpy as np
from fx import *
from fx import _XX, _YY
from chars import *
from scenes_a import vgrad, cached, motes, GOLD

C = (W / 2, H / 2 + 2)
R = 176
COL = {'gold': (1.0, 0.78, 0.30), 'gray': (0.62, 0.64, 0.70), 'red': (1.0, 0.22, 0.18), 'green': (0.3, 0.9, 0.5)}
EV = [(22, 'gold', None), (26, 'gold', None), (30, 'gold', None), (34, 'gold', None),
      (55, 'gray', None), (59, 'gold', 'همکار: سلام!'), (63, 'gray', None), (66, 'red', None), (70, 'green', None),
      (74, 'gold', 'دوستی که زنگ می‌زند'), (80, 'gray', None), (84, 'gold', 'فرصتی که می‌رسد'), (88, 'green', None), (94, 'gold', None),
      (100, 'gold', None), (106, 'gold', None), (112, 'green', None)]
KEY = [(0, 6.0), (20, 6.2), (55, 9.0), (90, 13.5), (120, 18.0), (150, 22.0)]
ENVS = [(0, 'bed'), (6.4, 'mat'), (7.6, 'desk'), (12.6, 'road'), (15.0, 'desk'), (17.6, 'carpet'), (21.0, 'bed')]
RINGT = 12.0


def hour_at(t):
    for (a, ha), (b, hb) in zip(KEY, KEY[1:]):
        if a <= t <= b:
            return lerp(ha, hb, (t - a) / (b - a))
    return KEY[-1][1]


def env_name(h):
    nm = ENVS[0][1]
    for s, n in ENVS:
        if h >= s:
            nm = n
    return nm


def env_img(name, t, awake):
    """top-down environment drawn at full canvas (masked later). returns Cv"""
    cv = Cv(vgrad([(0, (0.10, 0.07, 0.05)), (1, (0.08, 0.05, 0.04))]) * (0.6 + 0.9 * ncrop('fine', 0, 0)[..., None]) * 0.9)
    cx, cy = C
    if name == 'bed':
        cv.poly([(cx - 85, cy - 120), (cx + 85, cy - 120), (cx + 85, cy + 130), (cx - 85, cy + 130)], (0.22, 0.14, 0.12))
        cv.poly([(cx - 70, cy - 112), (cx + 70, cy - 112), (cx + 70, cy - 70), (cx - 70, cy - 70)], (0.75, 0.72, 0.68))   # pillow
        if awake < 0.5:
            cv.poly([(cx - 78, cy - 60), (cx + 78, cy - 60), (cx + 78, cy + 126), (cx - 78, cy + 126)], (0.18, 0.28, 0.40))  # blanket
            for i in range(6):
                cv.d.line([(cx - 78, cy - 40 + i * 28), (cx + 78, cy - 36 + i * 28)], fill=(36, 62, 88), width=2)
            cv.ell(cx, cy - 86, 18, 20, (0.82, 0.80, 0.78))   # night hijab on pillow
            cv.ell(cx + 2, cy - 82, 9, 11, (0.55, 0.40, 0.32))
        else:
            cv.poly([(cx - 78, cy + 40), (cx + 78, cy + 40), (cx + 78, cy + 126), (cx - 78, cy + 126)], (0.18, 0.28, 0.40))
        cv.rect(cx + 100, cy - 100, cx + 130, cy - 70, (0.2, 0.15, 0.1))     # nightstand
        cv.circ(cx + 115, cy - 85, 8, (1.0, 0.8, 0.4), 0.4)
    elif name == 'mat':
        cv.poly([(cx - 55, cy - 90), (cx + 55, cy - 90), (cx + 55, cy + 90), (cx - 55, cy + 90)], (0.5, 0.12, 0.10))
        cv.poly([(cx - 46, cy - 82), (cx + 46, cy - 82), (cx + 46, cy + 82), (cx - 46, cy + 82)], (0.62, 0.2, 0.14))
        cv.ell(cx, cy - 40, 22, 28, None, 0, outline=(0.9, 0.7, 0.3), w=2)
        cv.circ(cx + 150, cy - 40, 10, (0.6, 0.5, 0.2), 0.2)
        cv.circ(cx - 140, cy + 40, 12, (0.08, 0.12, 0.09))
    elif name == 'desk':
        cv.poly([(cx - 190, cy - 20), (cx + 190, cy - 20), (cx + 190, cy + 40), (cx - 190, cy + 40)], (0.24, 0.17, 0.12))
        cv.poly([(cx - 70, cy - 90), (cx + 70, cy - 90), (cx + 80, cy - 30), (cx - 80, cy - 30)], (0.07, 0.08, 0.1))
        cv.poly([(cx - 62, cy - 84), (cx + 62, cy - 84), (cx + 70, cy - 36), (cx - 70, cy - 36)], (0.35, 0.55, 0.7), 0.5)
        cv.circ(cx + 140, cy + 5, 11, (0.8, 0.8, 0.8))
        cv.circ(cx + 140, cy + 5, 8, (0.35, 0.2, 0.1))
        cv.rect(cx - 160, cy - 10, cx - 110, cy + 20, (0.8, 0.78, 0.7))
        pc = (0.15, 0.55, 0.9) if int(t * 2) % 2 else (0.1, 0.2, 0.3)
        cv.rect(cx + 90, cy + 8, cx + 110, cy + 32, pc, 0.4)
    elif name == 'road':
        cv.rect(0, 0, W, H, (0.07, 0.07, 0.09))
        for i in range(-1, 12):
            y = (i * 60 + t * 140) % (H + 120) - 60
            cv.rect(cx - 95, y, cx - 91, y + 30, (0.7, 0.7, 0.6))
            cv.rect(cx + 91, y, cx + 95, y + 30, (0.7, 0.7, 0.6))
        # other cars (traffic)
        for k, (ox, oy, c) in enumerate([(-170, -60, (0.5, 0.1, 0.1)), (170, -110, (0.2, 0.3, 0.5)), (-170, 110, (0.5, 0.5, 0.5)), (170, 90, (0.3, 0.3, 0.3))]):
            yy = cy + oy + math.sin(t * 0.7 + k) * 6
            cv.poly([(cx + ox - 28, yy - 55), (cx + ox + 28, yy - 55), (cx + ox + 28, yy + 55), (cx + ox - 28, yy + 55)], c)
            cv.rect(cx + ox - 20, yy - 8, cx + ox + 20, yy + 20, (0.08, 0.1, 0.12))
            cv.circ(cx + ox - 20, yy + 54, 4, (1, .1, .05), 0.9)
            cv.circ(cx + ox + 20, yy + 54, 4, (1, .1, .05), 0.9)
        cv.poly([(cx - 30, cy - 62), (cx + 30, cy - 62), (cx + 30, cy + 62), (cx - 30, cy + 62)], (0.78, 0.76, 0.7))
        cv.rect(cx - 22, cy - 25, cx + 22, cy + 12, (0.1, 0.12, 0.16))
        cv.circ(cx - 8, cy - 4, 8, (0.80, 0.74, 0.62))
    else:  # carpet
        cv.ell(cx, cy, 160, 130, (0.35, 0.10, 0.10))
        cv.ell(cx, cy, 130, 100, (0.22, 0.12, 0.2), outline=(0.8, 0.6, 0.25), w=2)
        cv.ell(cx, cy, 70, 50, None, 0, outline=(0.8, 0.6, 0.25), w=1)
        cv.circ(cx + 90, cy + 20, 18, (0.7, 0.65, 0.5))
        cv.circ(cx + 90, cy + 20, 13, (0.3, 0.17, 0.08))
        cv.circ(cx - 95, cy + 30, 11, (0.8, 0.5, 0.2))
    return cv


def traveler(cv, name, t, awake):
    cx, cy = C
    coat = (0.42, 0.14, 0.12)
    scarf = (0.12, 0.30, 0.36)
    if name in ('bed',) :
        return
    if name == 'mat':
        yoff = 8 + 6 * abs(math.sin(t * 0.8))
        cv.ell(cx, cy + 20, 26, 30, coat)
        cv.ell(cx, cy - 20 + yoff * 0.2, 17, 17, (0.82, 0.78, 0.7))
        return
    if name == 'road':
        return
    if name == 'desk':
        cv.ell(cx, cy + 62, 34, 15, coat)
        cv.ell(cx - 26, cy + 38, 6, 12, (0.6, 0.43, 0.33))
        cv.ell(cx + 26, cy + 38, 6, 12, (0.6, 0.43, 0.33))
        cv.ell(cx, cy + 60, 15, 15, scarf)
        return
    cv.ell(cx, cy + 6, 28, 15, coat)
    cv.ell(cx, cy + 2, 14, 14, scarf)


def hand(cv, x, y, ang, col, s=1.0):
    cv.ell(x, y, 7 * s, 8 * s, col, 0.7)
    for k in range(4):
        a = ang + (k - 1.5) * 0.28
        cv.line((x, y), (x + math.cos(a) * 13 * s, y + math.sin(a) * 13 * s), 3 * s, col, 0.6)
    a = ang + 1.8
    cv.line((x, y), (x + math.cos(a) * 9 * s, y + math.sin(a) * 9 * s), 3 * s, col, 0.6)


def clock(t, dur=150.0):
    h = hour_at(t)
    name = env_name(h)
    # next env crossfade
    awake = 1.0 if t > 20 else 0.0
    bgc = cached('clk_bg', lambda: vgrad([(0, (0.015, 0.02, 0.04)), (1, (0.01, 0.015, 0.03))]))
    cvE = env_img(name, t, awake)
    traveler(cvE, name, t, awake)
    # rings onto env, then mask by circle
    E = cvE.out(0.7)
    # cross fade at env change
    for s_, n_ in ENVS[1:]:
        hh = h - s_
        if -0.0 <= hh < 0.35 and n_ == name:
            prev = ENVS[[e[1] for e in ENVS].index(n_) - 1][1] if False else None
    mask = Image.new('L', (W, H), 0)
    ImageDraw.Draw(mask).ellipse([C[0] - R, C[1] - R, C[0] + R, C[1] + R], fill=255)
    mk = (np.asarray(mask).astype(np.float32) / 255)[..., None]
    # slow warm light + darken inside slightly so rings read
    a = bgc * (1 - mk) + E * 0.75 * mk
    cv = Cv(a)
    # dial ticks
    for i in range(48):
        ang = i / 48 * 2 * math.pi - math.pi / 2
        big = i % 4 == 0
        r0, r1 = R + 6, R + (18 if big else 11)
        cv.line((C[0] + math.cos(ang) * r0, C[1] + math.sin(ang) * r0), (C[0] + math.cos(ang) * r1, C[1] + math.sin(ang) * r1), 2 if big else 1,
                (0.7, 0.62, 0.45) if big else (0.28, 0.26, 0.22), 0.3 if big else 0)
    for i in range(12):
        ang = i / 12 * 2 * math.pi - math.pi / 2
        hh_ = 12 if i == 0 else i
        text(cv, fa(hh_), C[0] + math.cos(ang) * (R + 36), C[1] + math.sin(ang) * (R + 36) * 0.92, 15, (0.65, 0.58, 0.45), 0.7, 'r', shadow=False)
    cv.ell(C[0], C[1], R, R, None, 0.5, outline=(0.85, 0.7, 0.35), w=3)
    # hour hand marker
    ang = (h % 12) / 12 * 2 * math.pi - math.pi / 2
    for k in range(40):
        a2 = ang - k * 0.018
        cv.line((C[0] + math.cos(a2) * (R + 3), C[1] + math.sin(a2) * (R + 3)), (C[0] + math.cos(a2 - 0.02) * (R + 3), C[1] + math.sin(a2 - 0.02) * (R + 3)),
                3, (0.9 * (1 - k / 40), 0.6 * (1 - k / 40), 0.2 * (1 - k / 40)), 0.6)
    cv.line((C[0] + math.cos(ang) * (R - 16), C[1] + math.sin(ang) * (R - 16)), (C[0] + math.cos(ang) * (R + 24), C[1] + math.sin(ang) * (R + 24)), 4, (1, .85, .5), 1.5)
    # rings
    final = sm(seg(t, 118, 124))
    for i, (te, ck, lab) in enumerate(EV):
        u = (t - te) / RINGT
        if u < 0 or u > 1.0:
            continue
        r = 22 + (R - 22) * (1 - abs(1 - 2 * u))
        al = 0.95 - 0.3 * u
        c = COL[ck]
        cv.ell(C[0], C[1], r, r, None, 1.2 * al, outline=tuple(v * al for v in c), w=3)
        if u > 0.5 and r > 40:
            th = i * 2.399
            hx, hy = C[0] + math.cos(th) * r, C[1] + math.sin(th) * r
            hand(cv, hx, hy, th + math.pi, tuple(v * 0.95 for v in c), 0.9)
        if lab and 0.86 < u <= 1.0:
            text(cv, lab, C[0], C[1] - 52, 22, c, sm((u - 0.86) / 0.04) * (1 - sm((u - 0.97) / 0.03)), glow=0.8)
        if u > 0.95:
            q = (u - 0.95) / 0.05
            cv.circ(C[0], C[1], 14 + q * 24, None, 1.0 * (1 - q), outline=tuple(v * (1 - q) for v in c), w=2)
    # spectrum
    if final > 0:
        r_ = np.random.default_rng(6)
        order = r_.choice(['gold'] * 9 + ['green'] * 2 + ['gray'] * 2 + ['red'], 26)
        for i, ck in enumerate(order):
            rr = 16 + i * (R - 20) / 26
            c = COL[ck]
            pulse = 0.75 + 0.25 * math.sin(t * 1.5 - i * 0.4)
            cv.ell(C[0], C[1], rr, rr, None, 0.25 * final, outline=tuple(v * final * pulse * 0.8 for v in c), w=4)
    # lower text/time
    hr, mn = int(h), int((h % 1) * 60)
    text(cv, fa('%d:%02d' % (hr, mn)), 120, 330, 52, (1, .86, .5), 0.95, glow=0.7)
    text(cv, 'ساعتِ روز', 120, 368, 20, (0.75, 0.68, 0.55), 0.8, 'r')
    # legend
    for k, (nm, ck) in enumerate([('شکر', 'gold'), ('آرامش', 'green'), ('غر زدن', 'gray'), ('ترس', 'red')]):
        y = 90 + k * 28
        cv.circ(840, y, 7, COL[ck], 0.9)
        text(cv, nm, 888, y, 18, (0.85, 0.82, 0.75), 0.85, 'r', shadow=False)
    al = sm(seg(t, 92, 96)) * (1 - sm(seg(t, 114, 118)))
    text(cv, 'به وسیلهٔ دستانش', C[0], H - 18, 26, (1, .9, .6), al, glow=0.7)
    al = sm(seg(t, 126, 131))
    text(cv, 'طیفِ امروزِ تو', C[0], H - 18, 30, (1, .9, .6), al, glow=0.8)
    al = sm(seg(t, 2, 5)) * (1 - sm(seg(t, 14, 18)))
    text(cv, 'مسافر · ساعت ۶ صبح', C[0], 24, 22, (0.8, 0.75, 0.65), al * 0.9, 'r')
    return cv.out()
