import numpy as np, math
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import arabic_reshaper
from bidi.algorithm import get_display
import uharfbuzz as hb
from fontTools.ttLib import TTFont
from fontTools.pens.basePen import BasePen

W, H = 960, 396
FD = '/tmp/w/fonts/'
OUTW, OUTH = 1280, 720
ACTH = 528  # active picture height inside 1280x720 (2.42:1)
FA = '۰۱۲۳۴۵۶۷۸۹'


def fa(s):
    return ''.join(FA[int(c)] if c.isdigit() else c for c in str(s))


def clamp(x, a=0.0, b=1.0):
    return a if x < a else b if x > b else x


def sm(x):
    x = clamp(x)
    return x * x * (3 - 2 * x)


def lerp(a, b, t):
    return a + (b - a) * t


def lerpc(c1, c2, t):
    return tuple(lerp(a, b, t) for a, b in zip(c1, c2))


def seg(t, a, b):
    return clamp((t - a) / (b - a)) if b > a else (1.0 if t >= a else 0.0)


# ---------------------------------------------------------------- noise
def fft_noise(h, w, beta, seed):
    r = np.random.default_rng(seed)
    F = np.fft.fft2(r.standard_normal((h, w)))
    fy = np.fft.fftfreq(h)[:, None]
    fx = np.fft.fftfreq(w)[None, :]
    f = np.sqrt(fx ** 2 + fy ** 2)
    f[0, 0] = 1
    F = F / f ** beta
    F[0, 0] = 0
    a = np.fft.ifft2(F).real
    a = (a - a.min()) / (a.max() - a.min())
    return a.astype(np.float32)


_N = {}


def noise(kind):
    if kind not in _N:
        beta, seed = {'cloud': (2.2, 1), 'mid': (1.7, 2), 'fine': (1.1, 3), 'soil': (1.4, 4)}[kind]
        a = fft_noise(512, 1024, beta, seed)
        _N[kind] = np.tile(a, (2, 2))
    return _N[kind]


def ncrop(kind, ox, oy, h=H, w=W):
    N = noise(kind)
    ox = int(ox) % 1024
    oy = int(oy) % 512
    return N[oy:oy + h, ox:ox + w]


_YY, _XX = np.mgrid[0:H, 0:W].astype(np.float32)
YN = _YY / H
XN = _XX / W
VIG = (1 - 0.55 * (((XN - .5) * 1.5) ** 2 + ((YN - .5) * 1.7) ** 2)).clip(0.25, 1)[..., None].astype(np.float32)
_G = [np.random.default_rng(100 + i).standard_normal((H, W, 1)).astype(np.float32) for i in range(6)]


def c8(c):
    return tuple(int(clamp(v) * 255) for v in c)


# ---------------------------------------------------------------- canvas
class Cv:
    def __init__(s, arr=None):
        if arr is None:
            s.im = Image.new('RGB', (W, H), (0, 0, 0))
        else:
            s.im = Image.fromarray((np.clip(arr, 0, 1) * 255).astype(np.uint8))
        s.d = ImageDraw.Draw(s.im)
        s.gl = Image.new('RGB', (W // 4, H // 4))
        s.gd = ImageDraw.Draw(s.gl)

    def line(s, a, b, w, c, g=0.0):
        w = max(1, int(round(w)))
        s.d.line([a, b], fill=c8(c), width=w)
        if w > 3:
            r = w / 2 - 0.5
            s.d.ellipse([a[0] - r, a[1] - r, a[0] + r, a[1] + r], fill=c8(c))
            s.d.ellipse([b[0] - r, b[1] - r, b[0] + r, b[1] + r], fill=c8(c))
        if g > 0:
            s.gd.line([(a[0] / 4, a[1] / 4), (b[0] / 4, b[1] / 4)], fill=c8([g * v for v in c]), width=max(1, int(w / 3) + 1))

    def poly(s, pts, c, g=0.0, outline=None):
        s.d.polygon(pts, fill=c8(c), outline=c8(outline) if outline else None)
        if g > 0:
            s.gd.polygon([(x / 4, y / 4) for x, y in pts], fill=c8([g * v for v in c]))

    def circ(s, x, y, r, c, g=0.0, outline=None, w=1):
        s.d.ellipse([x - r, y - r, x + r, y + r], fill=c8(c) if c is not None else None,
                    outline=c8(outline) if outline else None, width=w)
        if g > 0:
            rr = max(r / 4, 0.8)
            s.gd.ellipse([x / 4 - rr, y / 4 - rr, x / 4 + rr, y / 4 + rr], fill=c8([g * v for v in (c or outline)]))

    def ell(s, x, y, rx, ry, c, g=0.0, outline=None, w=1):
        s.d.ellipse([x - rx, y - ry, x + rx, y + ry], fill=c8(c) if c is not None else None,
                    outline=c8(outline) if outline else None, width=w)
        if g > 0:
            col = c if c is not None else outline
            s.gd.ellipse([x / 4 - rx / 4, y / 4 - ry / 4, x / 4 + rx / 4, y / 4 + ry / 4],
                         fill=None if c is None else c8([g * v for v in col]),
                         outline=c8([g * v for v in col]) if c is None else None, width=max(1, int(w / 4) + 1))

    def rect(s, x0, y0, x1, y1, c, g=0.0):
        s.d.rectangle([x0, y0, x1, y1], fill=c8(c))
        if g > 0:
            s.gd.rectangle([x0 / 4, y0 / 4, x1 / 4, y1 / 4], fill=c8([g * v for v in c]))

    def out(s, glow=1.0):
        a = np.asarray(s.im).astype(np.float32) / 255
        g1 = s.gl.filter(ImageFilter.GaussianBlur(1.6)).resize((W, H), Image.BILINEAR)
        g2 = s.gl.resize((W // 16, H // 16), Image.BILINEAR).filter(ImageFilter.GaussianBlur(1.4)).resize((W, H), Image.BILINEAR)
        a += (np.asarray(g1).astype(np.float32) * 0.5 + np.asarray(g2).astype(np.float32) * 0.55) / 255 * glow
        return a


# ---------------------------------------------------------------- text
_F = {}


def font(name, size):
    k = (name, size)
    if k not in _F:
        _F[k] = ImageFont.truetype(FD + {'b': 'Vazir-Bold.ttf', 'r': 'Vazir-Regular.ttf', 'a': 'Amiri.ttf'}[name], size)
    return _F[k]


_RS = arabic_reshaper.ArabicReshaper()
_TM = {}


def tmask(text, size, fname='b'):
    k = (text, size, fname)
    if k not in _TM:
        t = get_display(_RS.reshape(text))
        f = font(fname, size)
        bb = f.getbbox(t)
        w, h = bb[2] + 12, bb[3] + 12
        m = Image.new('L', (w, h), 0)
        ImageDraw.Draw(m).text((6, 2), t, font=f, fill=255)
        _TM[k] = m
    return _TM[k]


def put_mask(im, m, cx, cy, color, alpha=1.0, shadow=True):
    x, y = int(cx - m.width / 2), int(cy - m.height / 2)
    mm = m.point(lambda v: int(v * alpha)) if alpha < 1 else m
    if shadow:
        sh = mm.filter(ImageFilter.GaussianBlur(3)).point(lambda v: int(v * 0.8))
        im.paste((0, 0, 0), (x + 2, y + 3), sh)
    im.paste(c8(color), (x, y), mm)


def text(cv, s, cx, cy, size, color=(1, 1, 1), alpha=1.0, fname='b', glow=0.0, shadow=True):
    if alpha <= 0.01:
        return
    m = tmask(s, size, fname)
    put_mask(cv.im, m, cx, cy, color, alpha, shadow)
    if glow > 0:
        gm = m.resize((max(1, m.width // 4), max(1, m.height // 4)), Image.BILINEAR).point(lambda v: int(v * alpha * glow))
        cv.gl.paste(c8(color), (int(cx / 4 - gm.width / 2), int(cy / 4 - gm.height / 2)), gm)


def mask_put(cv, m, cx, cy, color, alpha=1.0, glow=0.0, shadow=False):
    """paste an arbitrary L mask (e.g. Quran text)"""
    if alpha <= 0.01:
        return
    put_mask(cv.im, m, cx, cy, color, alpha, shadow)
    if glow > 0:
        gm = m.resize((max(1, m.width // 4), max(1, m.height // 4)), Image.BILINEAR).point(lambda v: int(v * alpha * glow))
        cv.gl.paste(c8(color), (int(cx / 4 - gm.width / 2), int(cy / 4 - gm.height / 2)), gm)


# -------------------------------------------- harfbuzz arabic (Quran) text
class _Pen(BasePen):
    def __init__(s, gs):
        super().__init__(gs)
        s.cs = []
        s.cur = None

    def _moveTo(s, p):
        s.cur = [p]

    def _lineTo(s, p):
        s.cur.append(p)

    def _curveToOne(s, p1, p2, p3):
        p0 = s.cur[-1]
        for i in range(1, 9):
            t = i / 8
            u = 1 - t
            s.cur.append((u ** 3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t ** 3 * p3[0],
                          u ** 3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t ** 3 * p3[1]))

    def _qCurveToOne(s, p1, p2):
        p0 = s.cur[-1]
        for i in range(1, 7):
            t = i / 6
            u = 1 - t
            s.cur.append((u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0], u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]))

    def _closePath(s):
        if s.cur:
            s.cs.append(s.cur)
        s.cur = None

    _endPath = _closePath


def quran_mask(txt, px, fpath=FD + 'Amiri.ttf'):
    S = 3
    face = hb.Face(hb.Blob.from_file_path(fpath))
    f = hb.Font(face)
    buf = hb.Buffer()
    buf.add_str(txt)
    buf.direction = 'rtl'
    buf.script = 'Arab'
    buf.language = 'ar'
    hb.shape(f, buf, {'kern': True, 'liga': True, 'mark': True, 'mkmk': True, 'calt': True})
    tt = TTFont(fpath)
    gs = tt.getGlyphSet()
    order = tt.getGlyphOrder()
    upm = tt['head'].unitsPerEm
    sc = px / upm * S
    total = sum(p.x_advance for p in buf.glyph_positions) * sc
    pad = int(px * 0.6 * S)
    Wm, Hm = int(total + 2 * pad), int(px * 2.4 * S)
    base = int(px * 1.5 * S)
    canvas = np.zeros((Hm, Wm), bool)
    x = pad
    for info, pos in zip(buf.glyph_infos, buf.glyph_positions):
        pen = _Pen(gs)
        gs[order[info.codepoint]].draw(pen)
        if pen.cs:
            polys = [[(x + (a + pos.x_offset) * sc, base - (b + pos.y_offset) * sc) for a, b in c] for c in pen.cs]
            xs = [p[0] for pl in polys for p in pl]
            ys = [p[1] for pl in polys for p in pl]
            x0, x1, y0, y1 = int(min(xs)) - 2, int(max(xs)) + 3, int(min(ys)) - 2, int(max(ys)) + 3
            acc = np.zeros((y1 - y0, x1 - x0), bool)
            for pl in polys:
                tmp = Image.new('L', (x1 - x0, y1 - y0), 0)
                ImageDraw.Draw(tmp).polygon([(a - x0, b - y0) for a, b in pl], fill=255)
                acc ^= np.asarray(tmp) > 0
            canvas[y0:y1, x0:x1] |= acc
        x += pos.x_advance * sc
    m = Image.fromarray((canvas * 255).astype(np.uint8)).resize((Wm // S, Hm // S), Image.LANCZOS)
    return m.crop(m.getbbox())


# ---------------------------------------------------------------- camera / post
def zoom(arr, z, cx=0.5, cy=0.5):
    if abs(z - 1) < 1e-3:
        return arr
    im = Image.fromarray((np.clip(arr, 0, 1) * 255).astype(np.uint8))
    w, h = W / z, H / z
    x0 = clamp(cx * W - w / 2, 0, W - w)
    y0 = clamp(cy * H - h / 2, 0, H - h)
    im = im.resize((W, H), Image.BICUBIC, box=(x0, y0, x0 + w, y0 + h))
    return np.asarray(im).astype(np.float32) / 255


def post(a, fi, bloom=1.0, grade=(1.0, 1.0, 1.0), sat=1.0):
    a = np.clip(a, 0, 3)
    br = np.maximum(a - 0.6, 0)
    s6 = br.reshape(H // 6, 6, W // 6, 6, 3).mean((1, 3))
    im6 = Image.fromarray((np.clip(s6, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(2.2)).resize((W, H), Image.BILINEAR)
    s12 = br.reshape(H // 12, 12, W // 12, 12, 3).mean((1, 3))
    im12 = Image.fromarray((np.clip(s12, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(2.0)).resize((W, H), Image.BILINEAR)
    a = a + bloom * (np.asarray(im6).astype(np.float32) / 255 * 0.55 + np.asarray(im12).astype(np.float32) / 255 * 0.7)
    a = np.clip(a, 0, 1)
    a = a * a * (3 - 2 * a) * 0.45 + a * 0.55
    lum = a.mean(2, keepdims=True)
    a = lum + (a - lum) * (1.08 * sat)
    a = a * np.array(grade, np.float32)
    a = a * VIG
    a = a + _G[fi % 6] * 0.022
    return np.clip(a, 0, 1)


def to_canvas(a):
    im = Image.fromarray((a * 255).astype(np.uint8)).resize((OUTW, ACTH), Image.BICUBIC)
    full = Image.new('RGB', (OUTW, OUTH), (0, 0, 0))
    full.paste(im, (0, (OUTH - ACTH) // 2))
    return full
