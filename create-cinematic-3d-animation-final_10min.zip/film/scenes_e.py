import math
import numpy as np
from fx import *
from fx import _XX, _YY
from chars import *
from scenes_a import vgrad, cached, motes, GOLD

COPPER = (0.78, 0.40, 0.18)


def counter(cv, t, dur, v0, v1, unit='لیتر', x=130, y=362):
    p = sm(seg(t, 0.5, dur * 0.8))
    v = math.exp(lerp(math.log(v0), math.log(v1), p))
    n = int(round(v))
    s = '{:,}'.format(n).replace(',', '٬')
    text(cv, fa(s) + ' ' + unit, x, y, 34, (1, .88, .6), 0.95, glow=0.7)


def drops(cv, t, rate, seed, area, glow=0.5, ripples=None, ry_ratio=0.36, col=(0.9, 0.8, 0.6), maxr=70, life=1.6, base=(0.25, 0.17, 0.12)):
    """rain ripples inside ellipse area (cx,cy,rx,ry)"""
    cx, cy, rx, ry = area
    r = np.random.default_rng(seed)
    n = int(rate * 60)
    ts = np.sort(r.random(n) * 60)
    pos = r.random((n, 2))
    for te, (u, v) in zip(ts, pos):
        d = t - te
        if d < 0:
            continue
        if d > life:
            continue
        a = u * 2 * math.pi
        rr = math.sqrt(v) * 0.92
        x, y = cx + math.cos(a) * rx * rr, cy + math.sin(a) * ry * rr
        k = d / life
        rad = 4 + k * maxr
        al = (1 - k) ** 1.5
        cc = tuple(b + (c - b) * al for c, b in zip(col, base))
        cv.ell(x, y, rad, rad * ry_ratio, None, glow * al, outline=cc, w=1)
        if k > 0.12:
            cv.ell(x, y, rad * 0.62, rad * 0.62 * ry_ratio, None, 0, outline=tuple(b + (c - b) * 0.6 for c, b in zip(cc, base)), w=1)
        if k < 0.12:
            for q in range(5):
                aa = q / 5 * math.pi
                cv.line((x, y), (x + math.cos(aa) * 10 * k * 8 * (1 if q % 2 else -1) * 0.6, y - math.sin(aa) * 18 * k * 8), 1, (1, 1, 1), 0.8)


def streaks(cv, t, n, seed, col=(0.75, 0.8, 0.9), ln=26, speed=900, slant=0.12, alpha=0.5, blur_glow=0.3):
    r = np.random.default_rng(seed)
    x0 = r.random(n) * (W + 200) - 100
    y0 = r.random(n) * H
    sp = speed * (0.7 + 0.6 * r.random(n))
    for i in range(n):
        y = (y0[i] + t * sp[i]) % (H + 60) - 30
        x = x0[i] + y * slant * 0.5
        cv.d.line([(x, y), (x + slant * ln, y + ln)], fill=c8(tuple(c * alpha * (0.5 + r.random() * 0.5) for c in col)), width=1)


def tasht(t, dur=20.0):
    p = clamp(t / dur)
    bg = cached('ts_bg', lambda: vgrad([(0, (0.10, 0.05, 0.03)), (0.5, (0.32, 0.17, 0.08)), (1, (0.06, 0.03, 0.02))]))
    cv = Cv(bg.copy())
    rr = np.random.default_rng(12)
    for i in range(30):
        bx, by, br = rr.random() * W, rr.random() * H * 0.6, 10 + rr.random() * 34
        al = (0.18 + 0.1 * math.sin(t * 0.9 + i)) * 2.2
        cv.circ(bx, by, br, (1.0 * al, 0.62 * al, 0.28 * al), 0.35)
    cx, cy = W / 2, 235
    rx, ry = 270, 98
    # body of basin
    cv.poly([(cx - rx, cy), (cx + rx, cy), (cx + rx - 70, cy + 130), (cx - rx + 70, cy + 130)], (0.32, 0.14, 0.06))
    for i in range(7):
        k = i / 7
        cv.d.line([(cx - rx + 70 * k, cy + 130 * k), (cx + rx - 70 * k, cy + 130 * k)], fill=c8((0.55 - 0.3 * k, 0.26 - 0.15 * k, 0.1)), width=2)
    cv.ell(cx, cy, rx + 10, ry + 8, COPPER, 0.5)
    cv.ell(cx, cy + 4, rx - 4, ry - 6, (0.12, 0.07, 0.04))
    # water
    wat = Image.new('RGB', (W, H))
    n = ncrop('fine', t * 20, 0)
    wa = np.zeros((H, W, 3), np.float32)
    wa[..., 0] = 0.08 + 0.35 * n
    wa[..., 1] = 0.10 + 0.20 * n
    wa[..., 2] = 0.12 + 0.12 * n
    wa *= (0.6 + 0.5 * (1 - YN))[..., None]
    arr = np.asarray(cv.im).astype(np.float32) / 255
    msk = Image.new('L', (W, H), 0)
    ImageDraw.Draw(msk).ellipse([cx - rx + 6, cy - ry + 8, cx + rx - 6, cy + ry - 2], fill=255)
    mk = (np.asarray(msk).astype(np.float32) / 255)[..., None]
    arr = arr * (1 - mk) + wa * mk
    cv2 = Cv(arr)
    cv2.gl = cv.gl
    cv2.gd = ImageDraw.Draw(cv2.gl)
    cv = cv2
    rate = lerp(2.5, 7, sm(p))
    drops(cv, t, rate, 3, (cx, cy + 2, rx - 20, ry - 14), 0.7, maxr=110, life=2.0, base=(0.25, 0.17, 0.12), col=(1.0, 0.8, 0.55))
    streaks(cv, t, 70, 5, alpha=0.55, speed=1100)
    # level rises slightly (rim light)
    cv.ell(cx, cy, rx + 10, ry + 8, None, 0.9, outline=(0.95, 0.55, 0.25), w=3)
    counter(cv, t, dur, 5, 5)
    return cv.out()


def hoz(t, dur=20.0):
    p = clamp(t / dur)
    bg = cached('hz_bg', lambda: vgrad([(0, (0.05, 0.07, 0.12)), (0.4, (0.22, 0.17, 0.14)), (1, (0.03, 0.04, 0.05))]))
    cv = Cv(bg.copy())
    # house with arches
    hy = 175
    cv.rect(0, 40, W, hy + 20, (0.24, 0.16, 0.11))
    for i in range(7):
        x = 70 + i * 130
        cv.poly([(x - 36, hy), (x - 36, 95)] + [(x + 36 * math.cos(a), 95 - 36 * math.sin(a)) for a in np.linspace(math.pi, 0, 12)] + [(x + 36, hy)], (0.08, 0.05, 0.04))
        wl = 0.5 + 0.3 * math.sin(t * 0.7 + i * 1.7)
        cv.rect(x - 20, 110, x + 20, hy - 6, (1.0 * wl, 0.62 * wl, 0.25 * wl), 0.5)
        cv.d.line([(x, 110), (x, hy - 6)], fill=(40, 25, 14), width=2)
    cv.rect(0, 30, W, 46, (0.12, 0.08, 0.06))
    # pool (turquoise) in perspective
    top, bot = hy + 28, H - 6
    xa0, xa1 = 190, 770
    xb0, xb1 = 30, 930
    cv.poly([(xa0 - 14, top - 8), (xa1 + 14, top - 8), (xb1 + 24, bot + 10), (xb0 - 24, bot + 10)], (0.35, 0.28, 0.2))
    pts = [(xa0, top), (xa1, top), (xb1, bot), (xb0, bot)]
    n = ncrop('fine', t * 12, 40)
    # water fill
    wa = np.zeros((H, W, 3), np.float32)
    wa[..., 0] = 0.02 + 0.08 * n
    wa[..., 1] = 0.35 + 0.30 * n
    wa[..., 2] = 0.40 + 0.30 * n
    wa *= (0.55 + 0.45 * YN)[..., None]
    arr = np.asarray(cv.im).astype(np.float32) / 255
    msk = Image.new('L', (W, H), 0)
    ImageDraw.Draw(msk).polygon(pts, fill=255)
    mk = (np.asarray(msk).astype(np.float32) / 255)[..., None]
    arr = arr * (1 - mk) + wa * mk
    cv2 = Cv(arr)
    cv2.gl = cv.gl
    cv2.gd = ImageDraw.Draw(cv2.gl)
    cv = cv2
    # tiles
    for i in range(1, 8):
        f = i / 8
        cv.d.line([(lerp(xa0, xa1, f), top), (lerp(xb0, xb1, f), bot)], fill=(20, 110, 120), width=1)
    for j in range(1, 6):
        f = (j / 6) ** 1.5
        cv.d.line([(lerp(xa0, xb0, f), lerp(top, bot, f)), (lerp(xa1, xb1, f), lerp(top, bot, f))], fill=(20, 110, 120), width=1)
    drops(cv, t, 16, 8, (480, (top + bot) / 2 + 20, 340, 110), 0.5, ry_ratio=0.3, maxr=70, life=1.5, col=(0.8, 1, 1), base=(0.08, 0.40, 0.45))
    streaks(cv, t, 90, 6, alpha=0.5)
    counter(cv, t, dur, 500, 500)
    return cv.out()


def pool_sea(t, dur=20.0):
    """0-10s: swimming pool top-down; 10-20s: sea shore"""
    cv = None
    if t < 10.5:
        n = ncrop('fine', t * 10, 10)
        wa = np.zeros((H, W, 3), np.float32)
        c2 = ncrop('mid', t * 6, 100 + t * 3)
        wa[..., 0] = 0.0 + 0.10 * n
        wa[..., 1] = 0.30 + 0.30 * n + 0.1 * c2
        wa[..., 2] = 0.48 + 0.30 * n + 0.1 * c2
        caus = np.exp(-((ncrop('fine', t * 12, 200) - ncrop('fine', 300 - t * 7, 10 + t * 5)) / 0.04) ** 2)
        wa += caus[..., None] * np.array([0.25, 0.45, 0.5], np.float32) * 0.5
        cv = Cv(wa)
        for i in range(1, 6):
            y = i * H / 6
            for x in range(20, W, 34):
                cv.d.line([(x, y), (x + 20, y)], fill=(230, 235, 240), width=3)
        cv.rect(0, 0, 40, H, (0.7, 0.72, 0.7))
        cv.rect(W - 40, 0, W, H, (0.7, 0.72, 0.7))
        drops(cv, t, 28, 14, (W / 2, H / 2, 420, 170), 0.5, ry_ratio=1.0, maxr=60, life=1.4, col=(0.9, 1, 1), base=(0.1, 0.5, 0.65))
        streaks(cv, t, 90, 7, alpha=0.45)
        v0, v1 = 50000, 50000
        out = cv
        out_t = t
        counter(cv, t, dur, v0, v1, x=170)
        return cv.out()
    # sea
    tt = t - 10.5
    hz = 140
    top = vgrad([(0, (0.22, 0.26, 0.32)), (0.36, (0.52, 0.56, 0.60)), (0.37, (0.10, 0.18, 0.24)), (1, (0.03, 0.08, 0.12))])
    n = ncrop('mid', tt * 12, 20)
    cl = ncrop('cloud', tt * 5, 60)
    a = top.copy()
    a[:int(hz)] *= (0.6 + 0.5 * cl[:int(hz), :, None])
    k = np.clip((YN * H - hz) / (H - hz), 0, 1)
    wv = 0.5 + 0.5 * np.sin(k * 90 - tt * 2.4 + n * 6)
    sea = np.zeros((H, W, 3), np.float32)
    sea[..., 0] = 0.02 + 0.06 * wv * k
    sea[..., 1] = 0.12 + 0.20 * wv * k
    sea[..., 2] = 0.17 + 0.22 * wv * k
    foam = np.exp(-((wv - 1) / 0.1) ** 2) * k * (n > 0.45)
    sea += foam[..., None] * 0.35
    a = np.where((_YY > hz)[..., None], sea, a)
    cv = Cv(a)
    drops(cv, t, 70, 31, (W / 2, 275, 440, 100), 0.3, ry_ratio=0.32, maxr=36, life=1.0, col=(0.8, 0.9, 1), base=(0.07, 0.25, 0.33))
    streaks(cv, t, 120, 9, alpha=0.5, speed=1000)
    counter(cv, t, dur, 5000000, 5000000, x=190)
    return cv.out()


def ocean_earth(t, dur=30.0):
    p = clamp(t / dur)
    sp = cached('earth_sp', lambda: _sphere())
    cvbg = cached('earth_bg', lambda: vgrad([(0, (0.005, 0.01, 0.02)), (1, (0.005, 0.008, 0.015))]))
    cx, cy, Rr = W * 0.5, H * 0.52, 165 + 12 * sm(p)
    sc = Rr / 165
    # sphere math at fixed 165 radius then scaled by PIL
    mk, lon, lat, nz = sp
    tex = ncrop('cloud', 0, 0, 512, 1024)
    tex2 = ncrop('mid', 0, 0, 512, 1024)
    u = ((lon / (2 * math.pi) + 0.5 + t * 0.012) % 1.0)
    iu = (u * 1023).astype(int)
    iv = ((lat / math.pi + 0.5) * 511).astype(int)
    cloud = np.clip((tex[iv, iu] - 0.50) * 3.2, 0, 1)
    storm = np.clip((tex2[iv, (iu + 300) % 1024] - 0.55) * 4, 0, 1) * 0.6
    ocean = np.stack([0.02 + 0.03 * tex2[iv, iu], 0.10 + 0.12 * tex2[iv, iu], 0.22 + 0.2 * tex2[iv, iu]], -1)
    land = (tex2[iv, (iu + 500) % 1024] > 0.66)[..., None]
    col = np.where(land, np.array([0.06, 0.09, 0.05], np.float32), ocean)
    cc = np.clip(cloud + storm, 0, 1)[..., None]
    col = col * (1 - cc * 0.85) + cc * np.array([0.55, 0.58, 0.62], np.float32) * 0.8
    lightv = np.clip(nz * 0.9 + 0.1, 0, 1)
    sun = np.clip(0.2 + 0.9 * lightv, 0, 1.2)
    col = col * sun[..., None] * mk[..., None]
    rim = (np.clip(1 - nz, 0, 1) ** 3 * mk)[..., None] * np.array([0.25, 0.5, 1.0], np.float32) * 1.4
    col = col + rim
    # map to canvas
    img = np.zeros((H, W, 3), np.float32)
    size = 2 * 165 + 2
    im = Image.fromarray((np.clip(col, 0, 1) * 255).astype(np.uint8))
    sz = int(size * sc)
    imr = im.resize((sz, sz), Image.BICUBIC)
    a = cvbg.copy()
    # stars
    cv = Cv(a)
    r = np.random.default_rng(3)
    for i in range(70):
        cv.circ(r.random() * W, r.random() * H, 0.8, (0.7, 0.7, 0.8))
    mimg = Image.fromarray((np.asarray(Image.fromarray((mk * 255).astype(np.uint8)).resize((sz, sz), Image.BICUBIC)))).convert('L')
    cv.im.paste(imr, (int(cx - sz / 2), int(cy - sz / 2)), mimg)
    # atmosphere glow
    cv.ell(cx, cy, Rr + 4, Rr + 4, None, 1.2, outline=(0.3, 0.55, 1.0), w=3)
    # rain streaks over globe area
    streaks(cv, t, 36, 11, col=(0.7, 0.85, 1), ln=14, alpha=0.5, speed=700)
    al = sm(seg(p, 0.45, 0.6))
    text(cv, 'شکر، تشت را اقیانوس می‌کند', W / 2, 56, 34, (1, .92, .65), al, glow=0.9)
    counter(cv, t, dur, 500000000, 500000000, x=215)
    return cv.out()


def _sphere():
    R = 165
    yy, xx = np.mgrid[-R - 1:R + 1, -R - 1:R + 1].astype(np.float32)
    xn, yn = xx / R, yy / R
    r2 = xn ** 2 + yn ** 2
    mk = (r2 < 1).astype(np.float32)
    zn = np.sqrt(np.clip(1 - r2, 0, 1))
    lon = np.arctan2(xn, zn)
    lat = np.arcsin(np.clip(-yn, -1, 1))
    ld = np.array([-0.5, -0.4, 0.75])
    ld = ld / np.linalg.norm(ld)
    nz = np.clip(xn * ld[0] * -1 * 0 + (xn * ld[0] + yn * ld[1] + zn * ld[2]), 0, 1)
    return mk, lon, lat, nz
