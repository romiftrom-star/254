import math
import numpy as np
from fx import *
from fx import _XX, _YY
from chars import *
from scenes_a import vgrad, cached, motes, GOLD

MW, MH = 1920, 792


def build_map():
    n = fft_noise(512, 1024, 2.1, 21)
    nl = np.asarray(Image.fromarray((n * 255).astype(np.uint8)).resize((MW, MH), Image.BICUBIC)).astype(np.float32) / 255
    nl = (nl - nl.min()) / (nl.max() - nl.min())
    land = nl > 0.50
    gy, gx = np.gradient(nl)
    relief = np.clip((-gx - gy) * 18, -0.5, 0.8)
    fine = np.asarray(Image.fromarray((fft_noise(512, 1024, 1.2, 5) * 255).astype(np.uint8)).resize((MW, MH), Image.BICUBIC)).astype(np.float32) / 255
    img = np.zeros((MH, MW, 3), np.float32)
    sea = np.array([0.012, 0.045, 0.095], np.float32)
    lnd = np.array([0.085, 0.105, 0.080], np.float32)
    img[:] = sea + fine[..., None] * 0.02
    L3 = land[..., None]
    img = np.where(L3, lnd * (0.7 + fine[..., None] * 0.8) * (1 + relief[..., None] * 2.2), img)
    lm = Image.fromarray((land * 255).astype(np.uint8))
    bl = np.asarray(lm.filter(ImageFilter.GaussianBlur(3))).astype(np.float32) / 255
    coast = np.exp(-((bl - 0.5) / 0.14) ** 2)
    img += coast[..., None] * np.array([0.05, 0.20, 0.30], np.float32) * 0.7
    # city lights
    r = np.random.default_rng(31)
    cl = np.asarray(Image.fromarray((fft_noise(512, 1024, 1.8, 8) * 255).astype(np.uint8)).resize((MW, MH), Image.BICUBIC)).astype(np.float32) / 255
    lights = np.zeros((MH, MW), np.float32)
    for _ in range(90000):
        x, y = r.integers(0, MW), r.integers(0, MH)
        if land[y, x] and cl[y, x] > 0.50 and r.random() < (cl[y, x] - 0.42) * 4:
            lights[y, x] = max(lights[y, x], 0.4 + r.random() * 0.6)
    lg = Image.fromarray((lights * 255).astype(np.uint8))
    lights = np.asarray(lg.filter(ImageFilter.GaussianBlur(0.8))).astype(np.float32) / 255 * 3 + np.asarray(lg.filter(ImageFilter.GaussianBlur(4))).astype(np.float32) / 255 * 6
    img += np.clip(lights, 0, 1.4)[..., None] * np.array([1.0, 0.68, 0.28], np.float32) * 1.3
    # village on coast
    ys, xs = np.nonzero((bl > 0.35) & (bl < 0.65))
    sel = (xs > 700) & (xs < 1300) & (ys > 200) & (ys < 600)
    if sel.sum() > 0:
        xs, ys = xs[sel], ys[sel]
    i = np.argmin((xs - 940) ** 2 + (ys - 400) ** 2)
    V = (float(xs[i]), float(ys[i]))
    ly, lx = np.nonzero(land)
    sub = np.arange(0, len(lx), 37)
    lxs, lys = lx[sub], ly[sub]

    def nearest(tx, ty):
        j = np.argmin((lxs - tx) ** 2 + (lys - ty) ** 2)
        return (float(lxs[j]), float(lys[j]))

    nodes = [V, nearest(V[0] + 190, V[1] - 70), nearest(V[0] + 370, V[1] - 170), nearest(V[0] - 160, V[1] - 230),
             nearest(V[0] - 420, V[1] - 90), nearest(V[0] - 640, V[1] - 250)]
    cities = [nearest(r.integers(100, MW - 100), r.integers(60, MH - 60)) for _ in range(34)]
    im = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    return dict(im=im, V=V, nodes=nodes, cities=cities)


def MAP():
    return cached('map', build_map)


def map_view(cx, cy, s, t=0.0, clouds=0.35, hud=True):
    M = MAP()
    bw, bh = W / s, H / s
    cx = clamp(cx, bw / 2, MW - bw / 2)
    cy = clamp(cy, bh / 2, MH - bh / 2)
    x0, y0 = cx - bw / 2, cy - bh / 2
    im = M['im'].resize((W, H), Image.BICUBIC, box=(x0, y0, x0 + bw, y0 + bh))
    a = np.asarray(im).astype(np.float32) / 255 * 1.8
    cl = ncrop('cloud', t * 4 + cx * 0.1, cy * 0.1)
    cm = np.clip((cl - 0.5) * 3, 0, 1)[..., None]
    a = a * (1 - cm * clouds * 0.7) + cm * clouds * np.array([0.05, 0.07, 0.1], np.float32)
    cv = Cv(a)
    tr = lambda p: ((p[0] - x0) * s, (p[1] - y0) * s)
    if hud:
        for gxm in range(0, MW, 160):
            X = (gxm - x0) * s
            if 0 <= X <= W:
                cv.d.line([(X, 0), (X, H)], fill=(10, 24, 34), width=1)
        for gym in range(0, MH, 132):
            Y = (gym - y0) * s
            if 0 <= Y <= H:
                cv.d.line([(0, Y), (W, Y)], fill=(10, 24, 34), width=1)
        for (ax, ay, dx, dy) in [(24, 20, 1, 1), (W - 24, 20, -1, 1), (24, H - 20, 1, -1), (W - 24, H - 20, -1, -1)]:
            cv.d.line([(ax, ay), (ax + 26 * dx, ay)], fill=(60, 120, 150), width=1)
            cv.d.line([(ax, ay), (ax, ay + 26 * dy)], fill=(60, 120, 150), width=1)
    return cv, tr, (x0, y0)


def village(cv, tr, V, s, t):
    X, Y = tr(V)
    r = np.random.default_rng(4)
    for i in range(18):
        ox, oy = (r.random() - .5) * 16, (r.random() - .5) * 10
        cv.circ(X + ox * s * 0.6, Y + oy * s * 0.6 - 2, max(0.8, s * 0.5), (1.0, 0.75, 0.35), 0.8)
    pul = 0.6 + 0.4 * math.sin(t * 2.6)
    cv.circ(X, Y, 3 + s * 1.2, (1.0, 0.85, 0.5), 1.4)
    rr = 14 + 10 * pul + s * 3
    cv.circ(X, Y, rr, None, 0.9, outline=(0.9 * pul, 0.7 * pul, 0.3 * pul), w=1)


# --------------------------------------------------- B1 night satellite village
def night_village(t, dur=25.0):
    M = MAP()
    p = clamp(t / dur)
    s = lerp(0.55, 3.6, sm(seg(p, 0.0, 0.95)) ** 1.1)
    V = M['V']
    cen = (MW / 2, MH / 2)
    q = sm(seg(p, 0.0, 0.9))
    cx, cy = lerp(cen[0], V[0], q), lerp(cen[1], V[1], q)
    cv, tr, _ = map_view(cx, cy, s, t)
    village(cv, tr, V, s, t)
    al = sm(seg(p, 0.62, 0.8))
    X, Y = tr(V)
    text(cv, 'مدار ۰ · روستا', X + 120, Y - 60, 24, GOLD, al, glow=0.7)
    cv.d.line([(X + 6, Y - 6), (X + 60, Y - 44)], fill=c8((0.8 * al, 0.6 * al, 0.3 * al)), width=1)
    return cv.out()


# --------------------------------------------------- B2a golden path
def golden_path(t, dur=16.0):
    M = MAP()
    nodes = M['nodes']
    p = clamp(t / dur)
    lens = [math.hypot(nodes[i + 1][0] - nodes[i][0], nodes[i + 1][1] - nodes[i][1]) for i in range(len(nodes) - 1)]
    tot = sum(lens)
    q = sm(seg(p, 0.04, 0.96)) * tot
    pts = [nodes[0]]
    acc = 0
    head = nodes[0]
    reached = 1
    for i, L in enumerate(lens):
        if q >= acc + L:
            pts.append(nodes[i + 1])
            reached = i + 2
        else:
            f = (q - acc) / L
            head = (lerp(nodes[i][0], nodes[i + 1][0], f), lerp(nodes[i][1], nodes[i + 1][1], f))
            pts.append(head)
            break
        acc += L
        head = nodes[i + 1]
    s = lerp(1.5, 0.72, sm(p))
    cv, tr, _ = map_view(lerp(nodes[0][0], head[0], 0.8) - 40, lerp(nodes[0][1], head[1], 0.8), s, t, 0.25)
    for i in range(len(pts) - 1):
        a, b = tr(pts[i]), tr(pts[i + 1])
        cv.line(a, b, 3, (1.0, 0.8, 0.35), 1.2)
    names = ['روستا', 'شهر', 'مرکز استان', 'پایتخت', 'خلیج', 'اروپا']
    for i in range(reached):
        X, Y = tr(nodes[i])
        age = t - (dur * 0.04 + 0)  # unused
        cv.circ(X, Y, 5, (1, .9, .6), 1.2)
        # steps icon
        for k in range(i + 1):
            cv.rect(X + 10 + k * 7, Y - 5 - k * 5, X + 15 + k * 7, Y + 4, (0.9, 0.7, 0.3), 0.8)
        text(cv, names[i], X, Y + 22, 15, (1, .92, .75), 0.9, 'r', glow=0.4)
        if i > 0:
            text(cv, 'پلهٔ ' + fa(i), X, Y - 22, 13, GOLD, 0.8, 'r')
    hx, hy = tr(head)
    cv.circ(hx, hy, 6, (1, 1, .9), 1.6)
    village(cv, tr, M['V'], s, t)
    return cv.out()


# --------------------------------------------------- B2b iso stairs of light
def iso_stairs(t, dur=14.0):
    p = clamp(t / dur)
    bg = cached('iso_bg', lambda: vgrad([(0, (0.02, 0.03, 0.06)), (0.6, (0.03, 0.05, 0.09)), (1, (0.01, 0.02, 0.03))]))
    a = bg + (ncrop('cloud', t * 4, 10)[..., None] ** 2) * np.array([0.03, 0.04, 0.07], np.float32)
    cv = Cv(a)
    cur = p * 9.2
    pan = sm(seg(p, 0.25, 0.95)) * 150
    n = 10
    for i in range(n):
        x = 90 + i * 74
        y = 340 - i * 38 + pan
        lit = clamp(cur - i + 0.5)
        fw, fh = 70, 30
        front = lerpc((0.07, 0.09, 0.13), (0.20, 0.17, 0.12), lit)
        topc = lerpc((0.12, 0.15, 0.22), (0.95, 0.72, 0.30), lit * 0.8)
        side = lerpc((0.04, 0.05, 0.08), (0.12, 0.09, 0.06), lit)
        cv.poly([(x, y), (x + fw, y), (x + fw, y + fh), (x, y + fh)], front)
        cv.poly([(x, y), (x + fw, y), (x + fw + 18, y - 11), (x + 18, y - 11)], topc, g=0.7 * lit)
        cv.poly([(x + fw, y), (x + fw + 18, y - 11), (x + fw + 18, y + fh - 11), (x + fw, y + fh)], side)
        if lit > 0.05:
            cv.line((x, y), (x + fw, y), 2, (1, .85, .5), lit)
            lab = 'مدار ' + (fa(i) if i == 0 else '+' + fa(i))
            text(cv, lab, x + 40, y - 30 - lit * 6, 18, (1, .88, .6), lit, glow=0.6)
        # pillars below
        cv.poly([(x, y + fh), (x + fw, y + fh), (x + fw, 460), (x, 460)], (0.03, 0.04, 0.06))
    # orb
    i = min(int(cur), n - 1)
    f = clamp(cur - i)
    ox = 90 + i * 74 + 35 + f * 74
    oy = 340 - i * 38 + pan - 38 * f - 22 - abs(math.sin(f * math.pi)) * 22
    cv.circ(ox + 8, oy, 9, (1, .95, .8), 2.0)
    cv.circ(ox + 8, oy, 20, None, 1.0, outline=(0.6, 0.45, 0.2), w=1)
    motes(cv, t, 50, 12, (1, .75, .35), speed=10, size=1.3)
    return cv.out()


# --------------------------------------------------- B3 water
def water(t, dur=25.0):
    p = clamp(t / dur)
    d0 = t * 38
    dist = d0 + _YY * 0.9
    xc = W / 2 + 130 * np.sin(dist / 210.0) + 70 * np.sin(dist / 97.0 + 1)
    hw = 7 + 520 * np.clip((dist - 80) / 1000.0, 0, 1) ** 1.6
    dd = np.abs(_XX - xc)
    inside = np.clip((hw - dd) / 5.0, 0, 1)[..., None]
    n1 = ncrop('mid', t * 6, d0 * 1.7 + 0)
    n2 = ncrop('mid', 400 - t * 4, d0 * 1.3 + 130)
    n3 = ncrop('mid', t * 3 + 200, d0 * 0.9)
    caus = np.exp(-((n1 - n2) / 0.022) ** 2)
    depth = np.clip(dd / np.maximum(hw, 1), 0, 1)
    wc = np.zeros((H, W, 3), np.float32)
    wc[..., 0] = 0.015 + 0.04 * n3 + 0.10 * (1 - depth) * 0.3
    wc[..., 1] = 0.12 + 0.12 * n3 + 0.10 * (1 - depth) * 0.3
    wc[..., 2] = 0.17 + 0.15 * n3 + 0.10 * (1 - depth) * 0.3
    spec = (np.clip(n1 - 0.62, 0, 1) * 5)[..., None] * np.array([1.0, 0.85, 0.6], np.float32)
    wc += caus[..., None] * np.array([0.25, 0.55, 0.6], np.float32) * 0.8 + spec * 0.5
    foam = np.exp(-((dd - hw) / 4.0) ** 2) * (0.5 + 0.5 * n1)
    wc += foam[..., None] * np.array([0.7, 0.8, 0.8], np.float32) * 0.6
    ln = ncrop('mid', 77 + d0 * 0.05, d0 * 1.1)
    lf = ncrop('fine', 10, d0 * 1.1 + 300)
    lc = np.zeros((H, W, 3), np.float32)
    k = 0.4 + 0.8 * ln
    lc[..., 0] = 0.10 * k + 0.05 * lf
    lc[..., 1] = 0.16 * k + 0.03 * lf
    lc[..., 2] = 0.035 * k
    shadow = np.exp(-np.clip(dd - hw, 0, 999) / 22.0)[..., None]
    lc = lc * (1 - 0.5 * shadow * (dd > hw)[..., None]) + shadow * (dd > hw)[..., None] * np.array([0.02, 0.05, 0.03], np.float32) * 0.0
    a = lc * (1 - inside) + wc * inside
    a *= np.array([1.0, 1.0, 1.0], np.float32)
    cv = Cv(a)
    # labels
    labs = [(0.0, 0.30, 'جوی کوچک'), (0.30, 0.55, 'رود'), (0.55, 0.78, 'مصب'), (0.78, 1.0, 'دریا')]
    for (a0, a1, s_) in labs:
        al = sm(seg(p, a0, a0 + 0.06)) * (1 - sm(seg(p, a1 - 0.05, a1)))
        text(cv, s_, W * 0.5, H * 0.14, 36, (0.9, 1, 1), al * 0.95, glow=0.5)
    al = sm(seg(p, 0.86, 0.94))
    text(cv, 'آب همان آب است؛ تو مثل آب سیّالی', W / 2, H * 0.86, 28, (1, .95, .8), al, glow=0.6)
    return cv.out()


# --------------------------------------------------- B4 internet branch
def net_branch(t, dur=30.0):
    M = MAP()
    p = clamp(t / dur)
    V = M['V']
    s = lerp(2.4, 0.5, sm(seg(p, 0.0, 0.85)))
    cx = lerp(V[0], MW / 2, sm(seg(p, 0.05, 0.9)))
    cy = lerp(V[1], MH / 2, sm(seg(p, 0.05, 0.9)))
    cv, tr, _ = map_view(cx, cy, s, t, 0.2)
    cities = M['cities']
    for i, c in enumerate(cities):
        st = 0.08 + i * 0.022
        f = sm(seg(p, st, st + 0.12))
        if f <= 0:
            continue
        a, b = V, c
        mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2 - math.hypot(b[0] - a[0], b[1] - a[1]) * 0.22)
        n = 22
        pts = []
        for k in range(int(n * f) + 1):
            u = k / n
            x = (1 - u) ** 2 * a[0] + 2 * u * (1 - u) * mid[0] + u * u * b[0]
            y = (1 - u) ** 2 * a[1] + 2 * u * (1 - u) * mid[1] + u * u * b[1]
            pts.append(tr((x, y)))
        for k in range(len(pts) - 1):
            cv.line(pts[k], pts[k + 1], 1.5, (0.55, 0.85, 1.0), 0.8)
        if f >= 1:
            X, Y = tr(c)
            cv.circ(X, Y, 3, (0.9, 1, 1), 1.0)
            u = (t * 0.45 + i * 0.13) % 1.0
            x = (1 - u) ** 2 * a[0] + 2 * u * (1 - u) * mid[0] + u * u * b[0]
            y = (1 - u) ** 2 * a[1] + 2 * u * (1 - u) * mid[1] + u * u * b[1]
            X, Y = tr((x, y))
            cv.circ(X, Y, 2.5, (1, 1, 1), 1.4)
    village(cv, tr, V, s, t)
    X, Y = tr(V)
    al = sm(seg(p, 0.05, 0.12)) * (1 - sm(seg(p, 0.35, 0.42)))
    text(cv, 'همان نقطه، همان روستا…', X + 150, Y - 54, 22, GOLD, al, glow=0.6)
    al = sm(seg(p, 0.78, 0.9))
    text(cv, 'در روستای خودش هم به همان اهداف می‌رسد', W / 2, H * 0.88, 28, (1, .95, .8), al, glow=0.6)
    return cv.out()


# --------------------------------------------------- B5 elevator vs stairs
def _flick(t):
    v = 0.75 + 0.25 * math.sin(t * 31) * math.sin(t * 7.3)
    if (t * 1.3) % 2.7 > 2.45:
        v *= 0.15
    return v


def stairs_elevator(t, dur=30.0):
    p = clamp(t / dur)
    bg = cached('se_bg', lambda: vgrad([(0, (0.05, 0.06, 0.08)), (1, (0.03, 0.035, 0.045))]))
    a = bg * (0.7 + 0.6 * ncrop('fine', 0, 0)[..., None])
    cv = Cv(a)
    # ---------- left: elevator shaft
    cv.rect(0, 0, 470, H, (0.045, 0.05, 0.06))
    for x in (60, 410):
        cv.d.line([(x, 0), (x, H)], fill=(18, 20, 26), width=3)
    fl = _flick(t)
    for i, y in enumerate((50, 190, 330)):
        cv.rect(0, y, 470, y + 8, (0.02, 0.02, 0.03))
        text(cv, fa(3 - i), 440, y - 14, 18, (0.9 * (0.5 + 0.5 * fl), 0.15, 0.1), 0.8, glow=0.4)
    jit = math.sin(t * 19) * 0.9 + (3.0 if (t * 0.9) % 3.1 > 2.9 else 0)
    cy0 = 120 + jit
    cv.line((235, 0), (235, cy0), 2, (0.2, 0.2, 0.22))
    cv.rect(145, cy0, 325, cy0 + 190, (0.10, 0.10, 0.11))
    cv.rect(151, cy0 + 6, 319, cy0 + 184, (0.62 * fl, 0.58 * fl, 0.46 * fl), 0.5 * fl)
    prims, _ = walker(120, 232, cy0 + 182, 0, face=1, kind='man', cols=dict(top=(0.10, 0.11, 0.14), bot=(0.06, 0.06, 0.07)), still=True, lean=0.02 + 0.02 * math.sin(t * 2))
    draw_prims(cv, prims, rim=(0.9, 0.85, 0.7), light=(-1.4, -1))
    # sparks
    if int(t * 6) % 5 == 0:
        for k in range(6):
            cv.circ(235 + math.sin(t * 90 + k) * 12, cy0 - 4 - k * 2, 1.4, (1, .8, .4), 1.0)
    text(cv, 'گیر کرده بین طبقات', 235, 372, 18, (0.9, 0.55, 0.45), sm(seg(p, 0.15, 0.25)) * 0.9, 'r')
    # ---------- right: stairs
    cv.rect(490, 0, W, H, (0.055, 0.06, 0.075))
    floors = [372, 268, 164, 60]
    for y in floors:
        cv.rect(490, y, W, y + 6, (0.025, 0.03, 0.04))
    xa, xb = 520, 920
    cur = p * 3.0
    flight = min(int(cur), 2)
    # flights
    for fi in range(3):
        y0, y1 = floors[fi], floors[fi + 1]
        right = fi % 2 == 0
        xs, xe = (xa, xb) if right else (xb, xa)
        lit = clamp(cur - fi)
        n = 13
        for k in range(n):
            xx = lerp(xs, xe, k / n)
            yy = lerp(y0, y1, k / n)
            c = lerpc((0.10, 0.11, 0.14), (0.45, 0.34, 0.20), lit)
            cv.rect(min(xx, xx + (xe - xs) / n) - 1, yy - 2, max(xx, xx + (xe - xs) / n) + 1, yy + 6, c, 0.2 * lit)
        cv.line((xs, y0), (xe, y1), 1, lerpc((.15, .15, .2), (1, .8, .4), lit), 0.8 * lit)
    # man
    fl_p = cur - flight
    walk = clamp((fl_p - 0.0) / 0.78)
    if cur >= 3.0:
        walk = 1.0
    right = flight % 2 == 0
    xs, xe = (xa, xb) if right else (xb, xa)
    y0, y1 = floors[flight], floors[flight + 1]
    mx = lerp(xs, xe, walk)
    my = lerp(y0, y1, walk)
    sl = (y1 - y0) / (xe - xs)
    phase = (t * 1.25) % 1.0
    prims, inf = walker(100, mx, my, phase, face=1 if right else -1, kind='man', cols=dict(top=(0.12, 0.13, 0.18), bot=(0.06, 0.06, 0.08)),
                        lean=0.14, stride=0.2, lift=0.14, slope=sl, still=(walk >= 1.0 or walk <= 0.0))
    draw_prims(cv, prims, rim=(1, .75, .4), light=(-1.4, -1), rimg=0.5)
    lessons = ['صبر', 'مهارت', 'تجربه']
    for fi in range(3):
        al = sm(seg(cur, fi + 0.78, fi + 0.95)) * (0.5 + 0.5 * (1 if cur < fi + 1.6 else 0.6))
        yb = floors[fi + 1]
        text(cv, 'یاد گرفت: ' + lessons[fi], 730, yb - 24, 20, (1, .88, .55), al, glow=0.7)
    text(cv, 'پله‌پله؛ در هر طبقه یک درس', 720, 392 - 8, 18, (1, .9, .65), sm(seg(p, 0.3, 0.4)) * 0.85, 'r')
    # divider
    cv.rect(468, 0, 472, H, (0.7, 0.55, 0.25), 0.6)
    return cv.out()
