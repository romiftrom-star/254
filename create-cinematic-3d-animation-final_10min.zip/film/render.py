import sys, os, json, subprocess, time
import numpy as np
from fx import *
import scenes_a as A, scenes_b as B, scenes_c as C, scenes_d as D, scenes_e as E
import imageio_ffmpeg

FPS = 24
TOTAL = 600
FF = imageio_ffmpeg.get_ffmpeg_exe()
OUT = '/tmp/w/out'
os.makedirs(OUT, exist_ok=True)

AYAT = {
    'sabr': ('وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ', 'سورهٔ بقره · آیهٔ ۴۵'),
    'tabaq': ('لَتَرْكَبُنَّ طَبَقًا عَن طَبَقٍ', 'سورهٔ انشقاق · آیهٔ ۱۹'),
}


def ayah_shot(key, px):
    def f(t, dur):
        txt, ref = AYAT[key]
        m = A.cached('ay_' + key, lambda: quran_mask(txt, px))
        return A.ayah_card(t, dur, m, ref)
    return f


# (start, dur, fn, dip, zoom0, zoom1, cx, cy)
S = [
    (0, 35, lambda t, d: A.roots(t, d), True, 1.0, 1.05, .5, .5),
    (35, 30, lambda t, d: A.farmer(t, d), False, 1.0, 1.14, .30, .62),
    (65, 20, lambda t, d: A.sprout(t, d), False, 1.0, 1.08, .55, .6),
    (85, 5, ayah_shot('sabr', 60), False, 1.0, 1.0, .5, .5),
    (90, 25, lambda t, d: B.night_village(t, d), True, 1.0, 1.0, .5, .5),
    (115, 16, lambda t, d: B.golden_path(t, d), False, 1.0, 1.0, .5, .5),
    (131, 14, lambda t, d: B.iso_stairs(t, d), False, 1.0, 1.05, .5, .5),
    (145, 25, lambda t, d: B.water(t, d), False, 1.0, 1.0, .5, .5),
    (170, 30, lambda t, d: B.net_branch(t, d), False, 1.0, 1.0, .5, .5),
    (200, 30, lambda t, d: B.stairs_elevator(t, d), False, 1.0, 1.04, .5, .5),
    (230, 10, ayah_shot('tabaq', 60), False, 1.0, 1.0, .5, .5),
    (240, 25, lambda t, d: C.foot_of_mountain(t, d), True, 1.0, 1.08, .4, .55),
    (265, 30, lambda t, d: C.stones_fall(t, d), False, 1.0, 1.05, .4, .55),
    (295, 30, lambda t, d: C.stones_station(t, d), False, 1.0, 1.10, .4, .7),
    (325, 25, lambda t, d: C.divine_light(t, d), False, 1.0, 1.05, .45, .5),
    (350, 10, lambda t, d: C.summit_wide(t, d), False, 1.0, 1.0, .5, .5),
    (360, 150, lambda t, d: D.clock(t, d), True, 1.0, 1.0, .5, .5),
    (510, 20, lambda t, d: E.tasht(t, d), True, 1.0, 1.06, .5, .6),
    (530, 20, lambda t, d: E.hoz(t, d), False, 1.0, 1.07, .5, .6),
    (550, 20, lambda t, d: E.pool_sea(t, d), False, 1.0, 1.04, .5, .5),
    (570, 30, lambda t, d: E.ocean_earth(t, d), False, 1.0, 1.04, .5, .5),
]
STARTS = [s[0] for s in S]

TITLES = {
    0: ('S12 · صبر؛ فاصلهٔ زمانی', 'ایستگاه دوم: ورودی‌های ذهن'),
    90: ('S13 · پلکان، نه آسانسور', 'ایستگاه دوم: ورودی‌های ذهن'),
    240: ('S14 · دوازده سنگ در کوله‌پشتی', 'ایستگاه دوم: ورودی‌های ذهن'),
    360: ('S15 · ذهن، فرستندهٔ فرکانس', 'ایستگاه سوم: ارسال فرکانس'),
    510: ('S16 · شکرگزاری؛ نزدیک‌ترین فرکانس', 'ایستگاه سوم: ارسال فرکانس'),
}
XF = 0.8
DIP = 1.0
try:
    SUBS = json.load(open('/tmp/w/subs.json'))
except Exception:
    SUBS = []


def shot_arr(i, tg):
    st, dur, fn, dip, z0, z1, cx, cy = S[i]
    tl = tg - st
    a = fn(max(tl, 0), dur)
    z = lerp(z0, z1, clamp(tl / dur))
    return zoom(a, z, cx, cy)


def compose(tg):
    i = max(k for k, s in enumerate(STARTS) if s <= tg + 1e-6)
    st, dur, fn, dip, *_ = S[i]
    tl = tg - st
    a = shot_arr(i, tg)
    if dip:
        a = a * sm(tl / DIP)
    elif i > 0 and tl < XF:
        b = shot_arr(i - 1, tg)
        f = sm(tl / XF)
        a = b * (1 - f) + a * f
    # fade-out before next dip shot / end
    if i + 1 < len(S) and S[i + 1][3]:
        left = (st + dur) - tg
        if left < DIP:
            a = a * sm(left / DIP)
    if tg > TOTAL - 1.5:
        a = a * sm((TOTAL - tg) / 1.5)
    return a


def overlay(img, tg):
    # titles
    for k, (ti, sub) in TITLES.items():
        d = tg - k - 1.3
        if 0 <= d < 4.2:
            al = sm(d / 0.8) * (1 - sm((d - 3.4) / 0.8))
            m = tmask(ti, 36, 'b')
            put_mask(img, m, OUTW / 2, OUTH / 2 - 6, (1, .9, .65), al, True)
            m2 = tmask(sub, 20, 'r')
            put_mask(img, m2, OUTW / 2, OUTH / 2 + 38, (0.85, 0.8, 0.7), al * 0.9, True)
    for (a, b, txt, who) in SUBS:
        if a <= tg <= b:
            al = sm((tg - a) / 0.25) * (1 - sm((tg - b + 0.25) / 0.25))
            col = (1, 1, 1) if who == 'master' else (0.8, 0.95, 1.0)
            # wrap manually if long
            words = txt.split(' ')
            lines, cur = [], ''
            for w in words:
                if len(cur) + len(w) > 46:
                    lines.append(cur)
                    cur = w
                else:
                    cur = (cur + ' ' + w).strip()
            lines.append(cur)
            y0 = OUTH - 48 - (len(lines) - 1) * 18
            for j, ln in enumerate(lines):
                m = tmask(ln, 25, 'r')
                put_mask(img, m, OUTW / 2, y0 + j * 36 - 6, col, al, True)
            break


def frame(fi):
    tg = fi / FPS
    a = compose(tg)
    a = post(a, fi, grade=(1.02, 1.0, 0.98))
    img = to_canvas(a)
    overlay(img, tg)
    return img


def render_range(f0, f1, path):
    cmd = [FF, '-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{OUTW}x{OUTH}', '-r', str(FPS), '-i', '-',
           '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', path]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    t0 = time.time()
    for fi in range(f0, f1):
        p.stdin.write(frame(fi).tobytes())
        if (fi - f0) % 120 == 0:
            print(f'{path} {fi - f0}/{f1 - f0} {time.time() - t0:.0f}s', flush=True)
    p.stdin.close()
    p.wait()
    print('done', path, time.time() - t0, flush=True)


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'still':
        for ts in sys.argv[2:]:
            tg = float(ts)
            t0 = time.time()
            img = frame(int(tg * FPS))
            img.save(f'/home/user/sandbox/film/stills/s_{ts}.png')
            print(ts, 'ok', round(time.time() - t0, 2), 's', flush=True)
    elif mode == 'chunk':
        # chunk index in 5-second pieces: python render.py chunk START_SEC END_SEC
        s, e = float(sys.argv[2]), float(sys.argv[3])
        render_range(int(s * FPS), int(e * FPS), f'{OUT}/c_{int(s):04d}.mp4')
