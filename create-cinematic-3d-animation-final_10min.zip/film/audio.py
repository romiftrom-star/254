import numpy as np, json, subprocess, os, sys, math
sys.path.insert(0, '/home/user/sandbox/film')
from script import *
import imageio_ffmpeg
from scipy.signal import butter, lfilter

FF = imageio_ffmpeg.get_ffmpeg_exe()
SR = 32000
DUR = 600
N = (DUR + 2) * SR
rng = np.random.default_rng(42)

music = np.zeros((2, N), np.float32)
sfx = np.zeros((2, N), np.float32)
voice = np.zeros(N, np.float32)


def add(buf, t0, sig, g=1.0, pan=0.0):
    i0 = int(t0 * SR)
    if i0 < 0 or i0 >= N:
        return
    if sig.ndim == 2:
        n_ = min(sig.shape[1], N - i0)
        buf[0, i0:i0 + n_] += sig[0, :n_] * g
        buf[1, i0:i0 + n_] += sig[1, :n_] * g
        return
    sig = sig[:N - i0]
    l, r = math.cos((pan + 1) * math.pi / 4), math.sin((pan + 1) * math.pi / 4)
    if buf.ndim == 1:
        buf[i0:i0 + len(sig)] += sig * g
    else:
        buf[0, i0:i0 + len(sig)] += sig * g * l * 1.414
        buf[1, i0:i0 + len(sig)] += sig * g * r * 1.414


def tt(d):
    return np.arange(int(d * SR), dtype=np.float32) / SR


def bp(x, lo, hi, order=2):
    b, a = butter(order, [lo / (SR / 2), hi / (SR / 2)], 'band')
    return lfilter(b, a, x).astype(np.float32)


def lp(x, f, order=2):
    b, a = butter(order, f / (SR / 2), 'low')
    return lfilter(b, a, x).astype(np.float32)


def hp(x, f, order=2):
    b, a = butter(order, f / (SR / 2), 'high')
    return lfilter(b, a, x).astype(np.float32)


def noise(d):
    return rng.standard_normal(int(d * SR)).astype(np.float32)


def env_ar(n, a, r):
    e = np.ones(n, np.float32)
    na, nr = int(a * SR), int(r * SR)
    if na > 0:
        e[:na] = np.linspace(0, 1, min(na, n))[:n]
    if nr > 0:
        e[-nr:] *= np.linspace(1, 0, min(nr, n))
    return e


def comb(x, D, g):
    y = np.zeros_like(x)
    for k in range(0, len(x), D):
        blk = x[k:k + D].copy()
        if k >= D:
            blk += g * y[k - D:k - D + len(blk)]
        y[k:k + len(blk)] = blk
    return y


# ------------------------------------------------------------------ instruments
def pad(freqs, d, vol=0.1, bright=1.0):
    t = tt(d)
    out = np.zeros((2, len(t)), np.float32)
    for k, f in enumerate(freqs):
        for ch, det in ((0, 0.997), (1, 1.003)):
            ph = rng.random() * 6.28
            s = np.zeros_like(t)
            for h in range(1, 6):
                s += np.sin(2 * np.pi * f * det * h * t + ph * h) / (h ** (1.4 / bright))
            s *= (0.8 + 0.2 * np.sin(2 * np.pi * (0.2 + 0.05 * k) * t + ph))
            out[ch] += s
    out *= vol / len(freqs)
    out *= env_ar(len(t), min(3.0, d * 0.4), min(3.0, d * 0.4))
    return out


def ney(notes, vol=0.12):
    segs = []
    for f, d in notes:
        n = int(d * SR)
        t = np.arange(n, dtype=np.float32) / SR
        vib = 1 + 0.006 * np.sin(2 * np.pi * 5.2 * t) * np.minimum(t / 0.4, 1)
        ph = np.cumsum(2 * np.pi * f * vib / SR)
        s = np.sin(ph) + 0.35 * np.sin(2 * ph) + 0.15 * np.sin(3 * ph)
        br = bp(noise(d), f * 1.5, f * 4) * 0.25
        e = env_ar(n, 0.12, 0.25)
        segs.append((s + br) * e)
    return np.concatenate(segs) * vol if segs else np.zeros(1, np.float32)


def daf(kind='dum', vol=0.5):
    t = tt(0.5)
    if kind == 'dum':
        f = 55 + 70 * np.exp(-t * 18)
        s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 7)
        s += hp(noise(0.5), 400) * np.exp(-t * 60) * 0.3
    else:
        s = hp(noise(0.5), 1800) * np.exp(-t * 38) * 0.5 + np.sin(2 * np.pi * 330 * t) * np.exp(-t * 30) * 0.15
    return s * vol


def ping(f, d=0.8, vol=0.2, partial=(1, 2.01, 3.02), decay=5.0):
    t = tt(d)
    s = sum(np.sin(2 * np.pi * f * p * t) / (i + 1) for i, p in enumerate(partial)) * np.exp(-t * decay)
    s *= np.minimum(t / 0.004, 1)
    return (s * vol).astype(np.float32)


def thud(vol=0.6, f0=95, d=0.6):
    t = tt(d)
    f = 40 + (f0 - 40) * np.exp(-t * 25)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 7)
    s += lp(noise(d), 700) * np.exp(-t * 18) * 0.5
    return (s * vol).astype(np.float32)


def step(vol=0.12, kind='dirt'):
    d = 0.18
    n = noise(d)
    t = tt(d)
    if kind == 'dirt':
        s = bp(n, 700, 4500) * np.exp(-t * 30) + lp(noise(d), 200) * np.exp(-t * 40) * 1.2
    else:
        s = lp(noise(d), 500) * np.exp(-t * 45) * 1.4
    return (s * vol).astype(np.float32)


def whoosh(d=1.2, vol=0.2, up=True):
    n = noise(d)
    t = tt(d)
    x = bp(n, 300, 3000)
    e = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 2
    return (x * e * vol).astype(np.float32)


# ------------------------------------------------------------------ MUSIC
CH = {
    'Dm': [73.4, 146.8, 174.6, 220.0, 293.7], 'Bb': [58.3, 116.5, 146.8, 174.6, 233.1], 'Gm': [98.0, 196.0, 233.1, 293.7],
    'A': [55.0, 110.0, 138.6, 164.8, 220.0], 'F': [87.3, 174.6, 220.0, 261.6], 'C': [65.4, 130.8, 164.8, 196.0, 261.6],
    'Eb': [77.8, 155.6, 196.0, 233.1], 'Am': [55.0, 110.0, 130.8, 164.8, 220.0],
}
SECTIONS = [  # start, end, chord cycle, vol, chord length
    (0, 35, ['Dm', 'Bb'], 0.07, 9), (35, 90, ['Dm', 'Bb', 'Gm', 'A'], 0.10, 8),
    (90, 240, ['Dm', 'F', 'C', 'Gm', 'Bb', 'A'], 0.11, 8), (240, 325, ['Dm', 'Dm', 'Gm', 'Dm'], 0.09, 10),
    (325, 360, ['Bb', 'F', 'C', 'Dm'], 0.13, 8), (360, 510, ['Dm', 'Bb', 'F', 'C', 'Gm', 'A'], 0.11, 8),
    (510, 600, ['Gm', 'Eb', 'Bb', 'F', 'Dm', 'A', 'Dm'], 0.13, 8),
]
for (a, b, cyc, vol, cl) in SECTIONS:
    k = 0
    t0 = a
    while t0 < b - 0.5:
        d = min(cl + 3, b - t0 + 3)
        v = vol * (1 + 0.4 * (t0 - a) / (b - a))
        add(music, t0, pad(CH[cyc[k % len(cyc)]], d, v), 1.0)
        t0 += cl
        k += 1
# ney phrases (D shur-ish: D Eb F# G A Bb C D)
D4, Eb4, Fs4, G4, A4, Bb4, C5, D5, E5 = 293.7, 311.1, 370.0, 392.0, 440.0, 466.2, 523.3, 587.3, 659.3
PH = [
    (36, [(A4, 2.5), (Bb4, 1.0), (A4, 1.5), (G4, 1.5), (Fs4, 1.0), (G4, 3.0), (A4, 4)]),
    (92, [(D4, 2), (A4, 3), (Bb4, 1.5), (A4, 1.5), (G4, 2), (A4, 4)]),
    (133, [(D5, 2), (C5, 1.5), (Bb4, 1.5), (A4, 2.5), (G4, 3)]),
    (252, [(D4, 4), (Eb4, 2), (D4, 5)]),
    (328, [(A4, 2), (D5, 3), (C5, 1.5), (Bb4, 1.5), (A4, 2), (D5, 5)]),
    (366, [(D4, 3), (A4, 3), (G4, 2), (A4, 2.5), (Bb4, 3)]),
    (440, [(D5, 3), (C5, 1.5), (A4, 1.5), (Bb4, 2), (A4, 4)]),
    (515, [(A4, 3), (Bb4, 1.5), (A4, 1.5), (G4, 2), (Fs4, 1.5), (G4, 4)]),
    (570, [(D5, 3), (E5, 2), (D5, 2), (C5, 2), (D5, 8)]),
]
for t0, notes in PH:
    s = ney(notes, 0.10)
    add(music, t0, s, 1.0, pan=0.25)
# drones
dr = tt(DUR + 1)
for (a, b, f, v) in [(0, 90, 36.7, 0.05), (90, 240, 36.7, 0.05), (240, 360, 36.7, 0.09), (360, 600, 36.7, 0.06)]:
    t = tt(b - a)
    s = (np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * f * 2 * t)) * env_ar(len(t), 4, 4) * v
    add(music, a, s.astype(np.float32), 1.0)
# heartbeat in tension S14
for k in range(int((325 - 265) / 1.3)):
    tb = 265 + k * 1.3
    v = 0.25 + 0.35 * k / 46
    add(music, tb, daf('dum', v), 1.0)
    add(music, tb + 0.28, daf('dum', v * 0.7), 1.0)
# daf accents
for tb in (85, 85.5, 86, 87, 230, 230.5, 231, 232, 481, 482, 483, 484.5):
    add(music, tb, daf('dum', 0.5), 1.0)
for k in range(8):
    add(music, 596 + k * 0.0 if False else 592 + k * 0.5, daf('dum' if k % 2 == 0 else 'tek', 0.35), 1.0)
for tb in range(575, 592, 2):
    add(music, tb, daf('dum', 0.3), 1.0)
    add(music, tb + 0.5, daf('tek', 0.25), 1.0)
    add(music, tb + 1.0, daf('tek', 0.2), 1.0)
# arpeggio in clock section (S15)

for k in range(int(150 / 0.5)):
    tb = 360 + k * 0.5
    f = [D4 * 1, A4, D5, A4][k % 4] * (1.0 if (k // 16) % 2 == 0 else 0.84)
    add(music, tb, ping(f, 0.7, 0.025, (1, 2, 3), 6), 1.0, pan=math.sin(k))
# reverb on music
for ch in range(2):
    x = music[ch]
    wet = comb(x, 3203 + ch * 71, 0.82)
    for D_, g_ in ((4129 + ch * 53, 0.80), (5351 + ch * 37, 0.78), (6173 + ch * 29, 0.76)):
        wet += comb(x, D_, g_)
    music[ch] = x + wet * 0.18
    del wet

# ------------------------------------------------------------------ SFX
def amb_noise(a, b, lo, hi, vol, mod=0.15):
    d = b - a
    n = bp(noise(d), lo, hi)
    t = tt(d)
    e = (0.7 + 0.3 * np.sin(2 * np.pi * mod * t + rng.random() * 6)) * env_ar(len(t), 3, 3)
    st = np.stack([n * e, np.roll(n, 2000) * e])
    add(sfx, a, st[0] * vol, 1.0, -0.4)
    add(sfx, a, st[1] * vol, 1.0, 0.4)


amb_noise(0, 35, 40, 220, 0.5, 0.1)                 # underground rumble
for k in range(30):
    add(sfx, 2 + rng.random() * 31, ping(rng.uniform(900, 1800), 0.5, 0.025, (1, 2.7), 12), 1.0, rng.uniform(-1, 1))  # tiny cracks/drips
amb_noise(35, 66, 300, 1400, 0.10, 0.08)            # evening wind
for k in range(40):
    tb = 36 + rng.random() * 28
    f0 = rng.uniform(2300, 3600)
    t = tt(0.09)
    ch = np.sin(2 * np.pi * np.cumsum(f0 + 1400 * t / 0.09) / SR) * env_ar(len(t), 0.01, 0.04) * 0.02
    add(sfx, tb, ch.astype(np.float32), 1.0, rng.uniform(-1, 1))
add(sfx, 47.5, ping(2300, 1.2, 0.07, (1, 1.5, 2.3), 6), 1.0, -0.3)   # tea glass
add(sfx, 56, ping(2250, 1.0, 0.04, (1, 1.5, 2.3), 6), 1.0, -0.3)
# radio: hiss + crackle
amb_noise(65, 86, 2500, 9000, 0.05, 0.4)
for k in range(110):
    tb = 65 + rng.random() * 20
    add(sfx, tb, (hp(noise(0.02), 1500) * np.exp(-tt(0.02) * 200) * 0.25).astype(np.float32), 1.0, rng.uniform(0.2, 1))
for tb in (73.0, 76.2, 79.0):
    add(sfx, tb, whoosh(1.4, 0.12), 1.0, 0.5)
add(sfx, 72.5, ping(520, 0.6, 0.06), 1.0)     # sprout
add(sfx, 77.0, ping(880, 1.2, 0.1, (1, 2, 3), 3), 1.0, 0.6)
# map pings
for i, tb in enumerate([115.5, 119, 122.5, 125.5, 128, 130.5]):
    add(sfx, tb, ping([587, 659, 740, 880, 988, 1175][i], 1.5, 0.12, (1, 2, 3), 3.5), 1.0)
for i in range(10):
    tb = 131 + 0.5 + i * 1.35
    add(sfx, tb, ping([293.7 * 2, 330 * 2, 370 * 2, 392 * 2, 440 * 2, 494 * 2, 554 * 2, 587 * 2, 659 * 2, 740 * 2][i], 1.6, 0.12, (1, 2, 3), 3), 1.0)
add(sfx, 142, whoosh(3, 0.15), 1.0)
# water
for a, b, v in [(145, 160, 0.10), (160, 170, 0.17)]:
    amb_noise(a, b, 600, 4500, v, 0.3)
for k in range(120):
    tb = 146 + rng.random() * 23
    f0 = rng.uniform(500, 1400)
    t = tt(0.1)
    s = np.sin(2 * np.pi * np.cumsum(f0 * (1 + 3 * t)) / SR) * np.exp(-t * 35) * 0.04
    add(sfx, tb, s.astype(np.float32), 1.0, rng.uniform(-1, 1))
amb_noise(163, 172, 40, 300, 0.25, 0.1)
# internet arcs
for i in range(34):
    tb = 170 + (0.08 + i * 0.022) * 30
    add(sfx, tb, ping(rng.uniform(1100, 2600), 0.5, 0.035, (1, 2), 8), 1.0, rng.uniform(-0.9, 0.9))
# elevator hum + dings + creaks + footsteps
t = tt(30)
fl = 0.75 + 0.25 * np.sin(t * 31) * np.sin(t * 7.3)
fl = np.where((t * 1.3) % 2.7 > 2.45, 0.1, fl)
hum = (np.sin(2 * np.pi * 50 * t) + 0.5 * np.sin(2 * np.pi * 100 * t) + 0.2 * np.sin(2 * np.pi * 150 * t)) * fl * 0.03
add(sfx, 200, hum.astype(np.float32), 1.0, -0.6)
for tb in (205.5, 212.0, 219.0, 225.5):
    add(sfx, tb, ping(1245, 1.0, 0.07, (1, 1.01, 2.4), 4.5), 1.0, -0.6)
    add(sfx, tb + 0.35, ping(1170, 1.0, 0.05, (1, 1.01, 2.4), 4.5), 1.0, -0.6)
for k in range(6):
    tb = 203 + k * 4.7 + rng.random()
    d = 1.3
    t2 = tt(d)
    s = bp(noise(d), 200, 900) * np.sin(np.pi * t2 / d) * (0.5 + 0.5 * np.sin(2 * np.pi * 9 * t2)) * 0.06
    add(sfx, tb, s.astype(np.float32), 1.0, -0.6)
for k in range(int(25 * 2.5)):
    tb = 203 + k / 2.5
    add(sfx, tb, step(0.07, 'floor'), 1.0, 0.6)
# mountain
amb_noise(240, 325, 200, 1200, 0.10, 0.07)
amb_noise(325, 360, 300, 2000, 0.07, 0.07)
for k in range(int(20 * 1.6)):
    add(sfx, 246 + k / 1.6, step(0.12), 1.0, 0.0)
T0, DT = 1.5, 2.35
tcur = 265.0
n = 0
while tcur < 295:
    nn = min(12, max(0, int((tcur - 265 - T0 - 1.7) / DT) + 1))
    sp = 1 - 0.65 * nn / 12
    add(sfx, tcur, step(0.12 * (1 + 0.5 * nn / 12)), 1.0)
    tcur += 1 / (1.6 * sp)
for i in range(12):
    ts = 265 + T0 + i * DT
    v = np.convolve(step(0.1), np.ones(1))  # dummy
    add(sfx, ts, whoosh(0.9, 0.12), 1.0, -0.8 if i % 2 == 0 else 0.8)
    add(sfx, ts + 1.7, thud(0.55 + 0.03 * i), 1.0, 0.0)
for i in range(12):
    add(sfx, 295 + 1.0 + i * 0.7, thud(0.25, 130, 0.35), 1.0, -0.5 + i / 12)
    tb = 295 + 10.5 + i * 1.05 + 0.4
    add(sfx, tb, (hp(noise(0.12), 900) * np.exp(-tt(0.12) * 50) * 0.35).astype(np.float32), 1.0, -0.5 + i / 12)
    add(sfx, tb, ping(190, 0.6, 0.12, (1, 1.5), 8), 1.0, -0.5 + i / 12)
    add(sfx, tb + 0.2, ping(155 + i * 4, 1.4, 0.05, (1, 1.06, 1.5), 3), 1.0)
for k in range(int(25 * 2.1)):
    add(sfx, 325 + k / 2.1, step(0.10), 1.0)
for k in range(24):
    add(sfx, 326 + k * 0.5, ping(587 * (1 + 0.5 * (k % 3)) * 0.5 * (1 + k % 2), 1.5, 0.03, (1, 2, 3), 3), 1.0, math.sin(k))
add(sfx, 326, whoosh(8, 0.12), 1.0)
# clock
for k in range(150):
    add(sfx, 360 + k, (hp(noise(0.03), 2500) * np.exp(-tt(0.03) * 150) * 0.12).astype(np.float32), 1.0, 0.5 if k % 2 else -0.5)
EVT = [(22, 'gold', 0), (26, 'gold', 0), (30, 'gold', 0), (34, 'gold', 0), (55, 'gray', 0), (59, 'gold', 1), (63, 'gray', 0), (66, 'red', 0), (70, 'green', 0), (74, 'gold', 1),
       (80, 'gray', 0), (84, 'gold', 1), (88, 'green', 0), (94, 'gold', 0), (100, 'gold', 0), (106, 'gold', 0), (112, 'green', 0)]
FQ = {'gold': 880, 'green': 659, 'gray': 220, 'red': 185}
for te, c, lab in EVT:
    add(sfx, 360 + te, ping(FQ[c], 2.0, 0.10 if c != 'gray' else 0.12, (1, 2, 3) if c != 'red' else (1, 1.06, 2.2), 2.5), 1.0, -0.5)
    if c == 'red':
        add(sfx, 360 + te, ping(196, 1.5, 0.05, (1, 1.07), 3), 1.0, 0.5)
    add(sfx, 360 + te + 12, ping(FQ[c] * 0.5, 2.0, 0.08, (1, 2, 3), 2.5), 1.0, 0.5)
    if lab:
        add(sfx, 360 + te + 12 + 0.3, ping(1318, 1.0, 0.07), 1.0)
        add(sfx, 360 + te + 12 + 0.55, ping(1046, 1.2, 0.07), 1.0)
amb_noise(360, 510, 100, 600, 0.04, 0.05)
add(sfx, 476, whoosh(6, 0.18), 1.0)
# alarm clock chirp at wake
for k in range(3):
    add(sfx, 372 + k * 0.4, ping(1760, 0.25, 0.04, (1, 2), 14), 1.0)
# rain section
t = tt(90)
rain = hp(noise(90), 1800) * (0.05 + 0.08 * np.clip(t / 40, 0, 1)) 
add(sfx, 510, np.stack([rain])[0].astype(np.float32), 1.0, -0.3)
add(sfx, 510, (hp(noise(90), 2500) * 0.05).astype(np.float32), 1.0, 0.3)
for k in range(110):
    tb = 510 + rng.random() * 20
    f0 = rng.uniform(1300, 3400)
    add(sfx, tb, ping(f0, 0.9, 0.05, (1, 1.51, 2.35, 3.1), 6), 1.0, rng.uniform(-0.7, 0.7))
for k in range(150):
    tb = 530 + rng.random() * 20
    f0 = rng.uniform(380, 1000)
    t3 = tt(0.12)
    add(sfx, tb, (np.sin(2 * np.pi * np.cumsum(f0 * (1 + 2.5 * t3)) / SR) * np.exp(-t3 * 30) * 0.05).astype(np.float32), 1.0, rng.uniform(-0.8, 0.8))
for k in range(8):   # surf
    tb = 560 + k * 1.25
    d = 3.0
    s = lp(noise(d), 1800) * np.sin(np.pi * tt(d) / d) ** 2 * 0.2
    add(sfx, tb + 5, s.astype(np.float32), 1.0, rng.uniform(-0.5, 0.5))
amb_noise(568, 600, 30, 160, 0.4, 0.05)
add(sfx, 566, whoosh(8, 0.12), 1.0)
for k in range(10):
    add(sfx, 583 + k * 1.2, ping(1174 * (1 + (k % 4) * 0.25), 2.0, 0.025, (1, 2, 3), 2), 1.0, math.sin(k))
add(sfx, 590, pad(CH['Dm'], 10, 0.2), 1.0) if False else None
add(music, 589, pad([73.4, 146.8, 220.0, 293.7, 440.0], 11, 0.22, 1.2), 1.0)

# ------------------------------------------------------------------ VOICE
def load(path, ss=None, d=None):
    cmd = [FF, '-loglevel', 'error']
    if ss is not None:
        cmd += ['-ss', str(ss), '-t', str(d)]
    cmd += ['-i', path, '-ac', '1', '-ar', str(SR), '-f', 'f32le', '-']
    raw = subprocess.run(cmd, capture_output=True).stdout
    return np.frombuffer(raw, np.float32).copy()


def echo(x, d=0.07, g=0.16):
    y = x.copy()
    k = int(d * SR)
    y[k:] += g * x[:-k]
    k2 = int(d * 2.1 * SR)
    y[k2:] += g * 0.5 * x[:-k2]
    return y


vmask = np.zeros(N, np.float32)
SRC = {'j3_3': '/tmp/w/audio/j3_3.mp3', 'j3_2': '/tmp/w/audio/j3_2.mp3', 'p1': '/tmp/w/audio/p1.mp3', 'p2': '/tmp/w/audio/p2.mp3'}
for id_, f, a, b, st, tx in MASTER:
    x = load(SRC[f], a, b - a)
    x = hp(x, 70)
    x = x / (np.percentile(np.abs(x), 99.5) + 1e-6) * 0.7
    x = np.tanh(x * 1.3) * 0.9
    x *= env_ar(len(x), 0.08, 0.15)
    add(voice, st, echo(x, 0.05, 0.1), 1.0)
    vmask[int(st * SR):int(st * SR) + len(x)] = 1
for id_, st, tx, v in NARR:
    x = load(f'/tmp/w/tts/{id_}.mp3')
    x = x / (np.abs(x).max() + 1e-6) * 0.75
    x *= env_ar(len(x), 0.05, 0.12)
    add(voice, st, echo(x, 0.08, 0.2), 1.0)
    vmask[int(st * SR):int(st * SR) + len(x)] = 1
for i in range(12):   # whispers
    x = load(f'/tmp/w/tts/w{i:02d}.mp3')
    x = lp(x, 3200) / (np.abs(x).max() + 1e-6) * 0.5
    x = echo(x, 0.11, 0.35)
    add(sfx, 265 + T0 + i * DT + 0.1, x * 0.45, 1.0, -0.7 if i % 2 == 0 else 0.7)

# ducking (low-res envelope, chunked final mix)
st_ = SR // 100
sm = np.convolve(vmask[::st_], np.ones(40) / 40, 'same').astype(np.float32)
del vmask
L = DUR * SR
mix = np.zeros((2, L), np.float32)
CHK = SR * 10
for a in range(0, L, CHK):
    b = min(L, a + CHK)
    idx = np.arange(a, b, dtype=np.float32)
    duck = np.interp(idx, np.arange(len(sm), dtype=np.float32) * st_, sm).astype(np.float32)
    mg = 1 - 0.55 * duck
    sg = 1 - 0.35 * duck
    fi = np.minimum(idx / (2 * SR), 1)
    fo = np.clip((DUR + 0.5 - idx / SR) / 3.0, 0, 1)
    for ch in range(2):
        mix[ch, a:b] = (music[ch, a:b] * mg * 0.95 + sfx[ch, a:b] * sg + voice[a:b]) * fi * fo
del music, sfx, voice
mix = np.tanh(mix * 1.1) * 0.95
pk = float(np.abs(mix).max())
print('peak', pk)
if pk > 0.9:
    mix *= 0.9 / pk
p = subprocess.Popen([FF, '-y', '-loglevel', 'error', '-f', 'f32le', '-ar', str(SR), '-ac', '2', '-i', '-', '-c:a', 'aac', '-b:a', '192k', '/tmp/w/out/audio.m4a'], stdin=subprocess.PIPE)
p.stdin.write(np.ascontiguousarray(mix.T).tobytes())
p.stdin.close()
p.wait()
print('audio done')
