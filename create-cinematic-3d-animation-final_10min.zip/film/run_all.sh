#!/bin/bash
cd /home/user/sandbox/film
w=$1
for s in $(seq $((w*30)) 60 570); do python3 render.py chunk $s $((s+30)) >> /tmp/w/render_$w.log 2>&1; done
echo ALLDONE >> /tmp/w/render_$w.log
