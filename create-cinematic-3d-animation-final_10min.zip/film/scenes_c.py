import math
import numpy as np
from fx import *
from fx import _XX, _YY
from chars import *
from scenes_a import vgrad, cached, motes, GOLD, ayah_card

PAL = {
    'dawn': dict(top=(0.16, 0.22, 0.42), bot=(1.0, 0.62, 0.42), lay=[(0.62, 0.48, 0.60), (0.45, 0.34, 0.48), (0.28, 0.22, 0.34), (0.13, 0.12, 0.17)], fog=(0.95, 0.62, 0.5)),
    'gray': dict(top=(0.22, 0.24, 0.28), bot=(0.50, 0.50, 0.53), lay=[(0.42, 0.44, 0.50), (0.32, 0.34, 0.40), (0.22, 0.24, 0.29), (0.11, 0.12, 0.14)], fog=(0.55, 0.56, 0.6)),
    'gold': dict(top=(0.08, 0.13, 0.30), bot=(1.0, 0.78, 0.45), lay=[(0.75, 0.58, 0.45), (0.55, 0.38, 0.30), (0.34, 0.24, 0.20), (0.16, 0.12, 0.10)], fog=(1.0, 0.85, 0.55)),
}


def mixpal(a, b, f):
    A, B = PAL[a], PAL[b]
    return dict(top=lerpc(A['top'], B['top'], f), bot=lerpc(A['bot'], B['bot'], f),
                lay=[lerpc(x, y, f) for x, y in zip(A['lay'], B['lay'])], fog=lerpc(A['fog'], B['fog'], f))


RID = [(0.50, 62, 0.0021, 0.04), (0.60, 52, 0.0032, 0.08), (0.69, 44, 0.0048, 0.16), (0.79, 34, 0.007, 0.30)]
SUMMIT = (W * 0.80, H * 0.13)


def ridge(x, k, cam):
    base, amp, fr, par = RID[k]
    xx = x + cam * par
    v = (math.sin(xx * fr * 3.1 + k) * 0.5 + math.sin(xx * fr * 7.3 + 2 * k) * 0.28 + math.sin(xx * fr * 15 + k * 3) * 0.12 + 0.5 * math.sin(xx * fr + 1.3 * k))
    return H * base - amp * v


def trail_y(x):
    return 380 - 0.17 * x


def mountain_bg(pal, cam, t, beams=0.0, fogamt=0.5, sunk=None):
    top, bot = pal['top'], pal['bot']
    a = vgrad([(0, top), (0.55, lerpc(top, bot, 0.8)), (1, bot)]).copy()
    n = ncrop('cloud', t * 3 + cam * 0.05, 30)
    cm = np.clip((n - 0.48) * 2.6, 0, 1) * np.clip(1.2 - YN * 1.5, 0, 1)
    a = a * (1 - cm[..., None] * 0.35) + cm[..., None] * np.array(pal['fog'], np.float32) * 0.25
    if beams > 0:
        sx, sy = SUMMIT
        d = np.hypot(_XX - sx, _YY - sy)
        ang = np.arctan2(_YY - sy, _XX - sx)
        rays = (0.5 + 0.5 * np.sin(ang * 14 + 2 * np.sin(ang * 4 + t * 0.2) + t * 0.15)) ** 3
        a += (np.exp(-d / 260) * 1.0 + rays * np.exp(-d / 520) * 0.55)[..., None] * np.array([1.0, 0.8, 0.45], np.float32) * beams
    cv = Cv(a)
    if sunk is not None:
        cv.circ(sunk[0], sunk[1], 26, (1, .95, .8), 1.4)
    out_layers = []
    for k in range(4):
        pts = [(x, ridge(x, k, cam)) for x in range(0, W + 12, 12)]
        col = pal['lay'][k]
        cv.poly(pts + [(W, H), (0, H)], col, g=0.0)
        # rim light on ridge top
        rimc = lerpc(col, (1, .85, .6), 0.5 * (0.3 + beams))
        for i in range(len(pts) - 1):
            cv.d.line([pts[i], pts[i + 1]], fill=c8(rimc), width=1)
        if k < 3:
            # fog band between layers
            yb = int(H * (RID[k][0] + 0.07))
            cv.gl  # no-op
            fa_ = fogamt * (0.5 + 0.5 * math.sin(t * 0.2 + k))
            ov = Image.new('RGB', (W, 90), c8(tuple(v * 0.35 * fogamt for v in pal['fog'])))
            m = Image.new('L', (W, 90))
            md = ImageDraw.Draw(m)
            for yy in range(90):
                md.line([(0, yy), (W, yy)], fill=int(110 * math.sin(yy / 90 * math.pi) * fogamt))
            cv.im.paste(ov, (0, yb - 45), m)
    return cv


def trail(cv, cam, pal, beams=0.0):
    col = tuple(v * 0.9 for v in pal['lay'][3])
    cv.poly([(0, trail_y(0)), (W, trail_y(W)), (W, H), (0, H)], col)
    rim = lerpc(col, (1, .85, .6), 0.45 + 0.3 * beams)
    cv.d.line([(0, trail_y(0)), (W, trail_y(W))], fill=c8(rim), width=2)
    r = np.random.default_rng(2)
    for i in range(34):
        s0 = r.random() * (W + 200)
        x = (W + 60) - ((s0 + cam * 1.0) % (W + 200))
        off = 8 + r.random() * 70
        y = trail_y(x) + off
        sz = 4 + r.random() * 14
        c = tuple(v * (0.6 + r.random() * 0.8) for v in col)
        cv.ell(x, y, sz * 1.4, sz * 0.8, c)
        cv.d.line([(x - sz, y - sz * 0.5), (x + sz * 0.5, y - sz * 0.75)], fill=c8(lerpc(c, (1, .85, .6), 0.35)), width=1)


GIRL = dict(skin=(0.60, 0.42, 0.32), top=(0.42, 0.14, 0.12), bot=(0.09, 0.09, 0.12), scarf=(0.10, 0.24, 0.30))
GX = 345


def girl(cv, t, pal, h=150, lean=0.08, stride=0.3, pack=True, still=False, x=GX, face=1, bendover=0.0, speed=1.0, beams=0.0, packw=0.19):
    y = trail_y(x)
    prims, info = walker(h, x, y, (t * 0.8 * speed) % 1.0, face=face, kind='woman', cols=GIRL, lean=lean, stride=stride, lift=0.10,
                         slope=-0.17, pack=dict(w=h * packw, h=h * 0.26, col=(0.22, 0.26, 0.12)) if pack else None, still=still, bendover=bendover)
    rim = lerpc((0.8, 0.6, 0.4), (1, .85, .5), beams)
    draw_prims(cv, prims, rim=rim, light=(1.6, -1.2) if face > 0 else (-1.6, -1.2), rimg=0.08)
    return info


def stone(cv, x, y, w, h, seed, label=None, flip=0.0, glow=0.0, dim=1.0):
    r = np.random.default_rng(seed)
    sq = abs(math.cos(math.pi * flip))
    ww = max(w * sq, 2)
    back = flip > 0.5
    base = (0.30, 0.29, 0.31) if not back else (0.26, 0.12, 0.12)
    base = tuple(v * dim for v in base)
    pts = []
    for k in range(9):
        a = k / 9 * 2 * math.pi
        rr = 0.5 + r.random() * 0.12
        pts.append((x + math.cos(a) * ww * rr, y + math.sin(a) * h * rr))
    cv.poly(pts, base, g=glow)
    cv.poly([(x - ww * 0.35, y - h * 0.3), (x + ww * 0.1, y - h * 0.42), (x + ww * 0.3, y - h * 0.2), (x - ww * 0.1, y - h * 0.05)], tuple(v * 1.35 for v in base))
    if sq > 0.45 and label:
        if back:
            text(cv, 'وعدهٔ شیطان', x, y + 1, 15, (1.0, 0.35, 0.3), sq * dim, glow=0.8, shadow=False)
        else:
            text(cv, label, x, y + 1, 15, (0.95, 0.95, 0.98), sq * dim, shadow=False)


PHRASES = ['دیر است', 'پارتی نداریم', 'سنم گذشته', 'تحریم', 'بقیه چه می‌گویند', 'پول نداریم', 'سرمایه نداریم',
           'بازار خراب است', 'تجربه ندارم', 'شرایط مساعد نیست', 'من لایق نیستم', 'نمی‌شود']


def foot_of_mountain(t, dur=25.0):
    p = clamp(t / dur)
    pal = mixpal('dawn', 'dawn', 0)
    cam = t * 55
    cv = mountain_bg(pal, cam, t, beams=0.2, fogamt=0.6, sunk=(W * 0.22, H * 0.46))
    trail(cv, cam, pal)
    still = p < 0.22
    girl(cv, t - 5.4, pal, h=165, lean=0.03 if still else 0.08, still=still, speed=1.0, beams=0.3)
    motes(cv, t, 30, 5, (1, .8, .5), speed=6, size=1.2, gl=0.6)
    return cv.out()


def stones_fall(t, dur=30.0):
    p = clamp(t / dur)
    pal = mixpal('dawn', 'gray', sm(seg(p, 0, 0.2)))
    T0, DT = 1.5, 2.35
    n = min(12, max(0, int((t - T0 - 1.7) / DT) + 1))
    sp = 1 - 0.65 * n / 12
    cam = sum(55 * (1 - 0.65 * min(i, 11) / 12) * 1.0 for i in range(0)) + t * 55 * sp
    shake = 0
    # thud shake
    for i in range(12):
        tt = t - (T0 + i * DT + 1.7)
        if 0 <= tt < 0.4:
            shake = math.sin(tt * 50) * 4 * (1 - tt / 0.4)
    cv = mountain_bg(pal, cam, t, beams=0.0, fogamt=0.7)
    trail(cv, cam, pal)
    lean = 0.05 + 0.34 * n / 12
    info = girl(cv, t, pal, h=165, lean=lean, stride=0.3 - 0.14 * n / 12, speed=sp, packw=0.19 + 0.10 * n / 12)
    pk = info['pack']
    r = np.random.default_rng(1)
    for i in range(n):
        a = i * 2.4
        cv.circ(pk[0] - 4 + math.cos(a) * 9, pk[1] + 22 + math.sin(a * 1.7) * 7, 6 + (i % 3), (0.30, 0.29, 0.31))
    # events
    for i in range(12):
        u = t - (T0 + i * DT)
        if u < 0 or u > 1.75:
            continue
        side = -1 if i % 2 == 0 else 1
        sx = GX + side * 330
        sy = 120 + (i % 3) * 22
        if u < 0.9:
            f = sm(u / 0.9)
            x = lerp(sx, GX + side * 130, f)
            y = lerp(sy, 150, f)
            al = sm(u / 0.3)
            text(cv, PHRASES[i], x, y, 22, (0.85, 0.86, 0.9), al * 0.9, glow=0.0)
            # whisper wisps
            for k in range(5):
                cv.circ(x + (k - 2) * 14 - side * k * 6, y + 20 + k * 3, 2, (0.5, 0.5, 0.55), 0)
        else:
            f = (u - 0.9) / 0.8
            x0, y0 = GX + side * 130, 150
            x = lerp(x0, pk[0], f)
            y = lerp(y0, pk[1] + 10, f * f) - math.sin(f * math.pi) * 40
            stone(cv, x, y, 46, 30, i + 10, PHRASES[i], 0.0)
    for i in range(12):
        uu = t - (T0 + i * DT + 1.7)
        if 0 <= uu < 0.6:
            for k in range(9):
                ang = k / 9 * math.pi
                cv.circ(pk[0] + math.cos(ang) * uu * 50 * (1 if k % 2 else -1), pk[1] + 40 - math.sin(ang) * uu * 30, 3 + uu * 6, (0.5 * (1 - uu / 0.6),) * 3)
    # counter
    text(cv, fa(n) + ' / ' + fa(12) + '  سنگ', 100, 40, 26, (0.85, 0.85, 0.9), 0.85, glow=0.0)
    out = cv.out()
    if shake:
        out = np.roll(out, int(shake), axis=0)
    return out


def stones_station(t, dur=30.0):
    p = clamp(t / dur)
    pal = mixpal('gray', 'gray', 0)
    cv = mountain_bg(pal, 40 + t * 2, t, fogamt=0.8)
    # ledge
    ly = 300
    cv.poly([(0, ly), (W, ly - 6), (W, H), (0, H)], (0.12, 0.12, 0.14))
    cv.d.line([(0, ly), (W, ly - 6)], fill=(90, 92, 100), width=2)
    # girl crouching at left
    bend = 0.9 * sm(seg(p, 0.0, 0.08))
    x = 80
    prims, info = walker(150, x, ly + 6, 0, face=1, kind='woman', cols=GIRL, lean=0.35 + 0.1 * math.sin(t * 0.8), stride=0, still=True, bendover=bend * 0.4,
                         pack=None)
    draw_prims(cv, prims, rim=(0.7, 0.7, 0.8), light=(1.5, -1.0))
    # backpack on ground
    cv.ell(34, ly + 4, 34, 16, (0.2, 0.23, 0.1))
    cv.d.line([(10, ly - 10), (58, ly - 10)], fill=(60, 66, 30), width=3)
    # stones
    n = 12
    for i in range(n):
        x_ = 190 + (i % 6) * 135
        yv = ly + 34 + (i // 6) * 50
        ap = sm(seg(t, 1.0 + i * 0.7, 1.6 + i * 0.7))
        if ap <= 0:
            continue
        drop = (1 - ap) * 80
        st0 = 10.5 + i * 1.05
        fl = sm(seg(t, st0, st0 + 0.9))
        glow = 0.9 * fl * (0.7 + 0.3 * math.sin(t * 5 + i))
        stone(cv, x_, yv - drop, 104, 44, i + 40, PHRASES[i], fl, glow=glow * 0.6, dim=ap)
    al = sm(seg(p, 0.72, 0.8))
    text(cv, 'پشتِ هر مانع، فقط یک وعده: وعدهٔ شیطان', W / 2, 90, 30, (1.0, 0.45, 0.4), al, glow=0.8)
    return cv.out()


def divine_light(t, dur=25.0):
    p = clamp(t / dur)
    pal = mixpal('gray', 'gold', sm(seg(p, 0.0, 0.3)))
    cam = t * 70
    beams = 0.7 * sm(seg(p, 0.05, 0.4))
    cv = mountain_bg(pal, cam, t, beams=beams, fogamt=0.5 - 0.3 * beams, sunk=None)
    trail(cv, cam, pal, beams)
    girl(cv, t, pal, h=165, lean=0.10, stride=0.34, pack=False, speed=1.35, beams=beams)
    motes(cv, t, 70, 7, (1, .85, .5), speed=18, size=1.6)
    cv2 = cv
    mask = cached('ayah268b', lambda: quran_mask('وَاللَّهُ يَعِدُكُم مَّغْفِرَةً مِّنْهُ وَفَضْلًا', 54))
    al = sm(seg(p, 0.32, 0.5)) * (1 - sm(seg(p, 0.93, 1.0)))
    sc = (W * 0.62) / mask.width
    m = mask.resize((int(mask.width * sc), int(mask.height * sc)), Image.LANCZOS)
    mask_put(cv2, m, W * 0.5, H * 0.17, (1.0, 0.95, 0.75), al, glow=0.8, shadow=True)
    text(cv2, 'وعدهٔ خدا: مغفرت و فضل', W / 2, H * 0.17 + 42, 24, GOLD, al, glow=0.8)
    return cv2.out()


def summit_wide(t, dur=10.0):
    p = clamp(t / dur)
    pal = PAL['gold']
    cam = 400 + t * 12
    cv = mountain_bg(pal, cam, t, beams=1.0, fogamt=0.35, sunk=(SUMMIT[0], SUMMIT[1] + 20))
    # near ridge foreground (dark)
    pts = [(x, H * 0.84 - 30 * (0.5 + 0.5 * math.sin(x * 0.01 + 2)) ) for x in range(0, W + 10, 10)]
    cv.poly(pts + [(W, H), (0, H)], (0.07, 0.05, 0.05))
    # tiny girl on the far ridge top
    gx = W * 0.70 + p * 30
    gy = ridge(gx, 1, cam) + 6
    prims, info = walker(34, gx, gy, (t * 0.5) % 1.0, face=1, kind='woman', cols=GIRL, lean=0.05, stride=0.28, slope=0, pack=None)
    draw_prims(cv, prims, rim=(1, .9, .6), light=(1.5, -1.0), rimg=1.0)
    # twelve stones left below, tiny
    for i in range(12):
        cv.ell(70 + i * 22, H * 0.9 + (i % 2) * 5, 8, 5, (0.22, 0.16, 0.16))
    motes(cv, t, 60, 17, (1, .85, .5), speed=14, size=1.4)
    return cv.out()
