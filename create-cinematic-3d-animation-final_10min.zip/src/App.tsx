const files = [
  { title: 'قطعهٔ کامل ۱۰ دقیقه‌ای (دقیقهٔ ۳۰ تا ۴۰ فیلم)', size: '۷۸ مگابایت', url: 'https://gofile.io/d/jWUWnNGa', main: true },
  { title: 'نیمهٔ اول · دقیقهٔ ۳۰ تا ۳۵', size: '۴۰ مگابایت', url: 'https://gofile.io/d/uvBH3mYN', main: false },
  { title: 'نیمهٔ دوم · دقیقهٔ ۳۵ تا ۴۰', size: '۳۷ مگابایت', url: 'https://gofile.io/d/aJEn38jU', main: false },
]

const scenes = [
  ['۰:۰۰ – ۱:۳۰', 'S12 · صبر؛ فاصلهٔ زمانی (ادامه)', 'ریشه‌های درخشان زیر خاک، کشاورز پیر در غروب، جوانه و رادیوی قدیمی، آیهٔ بقره ۴۵'],
  ['۱:۳۰ – ۴:۰۰', 'S13 · پلکان، نه آسانسور', 'نقشهٔ ماهواره‌ای شبانه، مسیر طلایی، پله‌های نور، آب سیّال، شاخهٔ دوم (اینترنت)، آسانسور و پلکان، آیهٔ انشقاق ۱۹'],
  ['۴:۰۰ – ۶:۰۰', 'S14 · دوازده سنگ در کوله‌پشتی', 'دختر مسافر با روسری در کوه، دوازده سنگ برچسب‌دار، وعدهٔ شیطان، وعدهٔ خدا (بقره ۲۶۸)'],
  ['۶:۰۰ – ۸:۳۰', 'S15 · ذهن، فرستندهٔ فرکانس', 'ساعتِ روز با نمای بالا، حلقه‌های رنگی شکر/آرامش/غر زدن/ترس، «به وسیلهٔ دستانش»، طیف روز'],
  ['۸:۳۰ – ۱۰:۰۰', 'S16 · شکرگزاری؛ نزدیک‌ترین فرکانس', 'باران در تشت مسی ← حوض ← استخر ← دریا ← اقیانوس، شمارندهٔ لیتر'],
]

export default function App() {
  return (
    <div dir="rtl" className="min-h-screen bg-[#07090f] text-stone-200" style={{ fontFamily: 'Tahoma, "Vazirmatn", sans-serif' }}>
      <header className="relative overflow-hidden border-b border-amber-500/20 px-6 py-14 text-center">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_0%,rgba(245,170,60,0.22),transparent_60%)]" />
        <p className="relative text-sm tracking-widest text-amber-400/80">بازیِ بزرگ · انیمیشن سینمایی ۱۲۰ دقیقه‌ای</p>
        <h1 className="relative mt-3 text-4xl font-black text-amber-100 md:text-5xl">بخش ۳۰ تا ۴۰ دقیقه</h1>
        <p className="relative mx-auto mt-4 max-w-2xl leading-8 text-stone-400">
          سکانس‌های S12 (ادامه) تا S16 بر پایهٔ فیلم‌نامهٔ کتاب، با صدای اصلی استاد باستین، راوی فارسی، موسیقی و افکت صوتی. ۱۰:۰۰ دقیقه، ۱۲۸۰×۷۲۰، ۲۴ فریم، قاب سینمایی ۲٫۴:۱.
        </p>
      </header>

      <main className="mx-auto max-w-4xl space-y-12 px-5 py-12">
        <section>
          <h2 className="mb-5 text-2xl font-bold text-amber-200">لینک‌های دانلود مستقیم (gofile.io)</h2>
          <div className="space-y-3">
            {files.map((f) => (
              <a
                key={f.url}
                href={f.url}
                target="_blank"
                rel="noreferrer"
                className={`flex items-center justify-between gap-4 rounded-2xl border px-5 py-4 transition hover:scale-[1.01] ${
                  f.main ? 'border-amber-400/60 bg-amber-500/10' : 'border-white/10 bg-white/5'
                }`}
              >
                <div>
                  <div className="font-bold text-stone-100">{f.title}</div>
                  <div className="mt-1 text-xs text-stone-500" dir="ltr">{f.url} · {f.size} · MP4 (H.264 + AAC)</div>
                </div>
                <span className="shrink-0 rounded-full bg-amber-400 px-4 py-2 text-sm font-bold text-black">دانلود</span>
              </a>
            ))}
          </div>
          <p className="mt-3 text-xs leading-6 text-stone-500">لینک‌های gofile برای مهمان ساخته شده‌اند و ممکن است پس از مدتی بدون استفاده حذف شوند؛ فایل را سریع ذخیره کنید.</p>
        </section>

        <section>
          <h2 className="mb-5 text-2xl font-bold text-amber-200">سکانس‌های این قطعه</h2>
          <div className="overflow-hidden rounded-2xl border border-white/10">
            {scenes.map(([t, n, d], i) => (
              <div key={i} className="grid gap-1 border-b border-white/5 bg-white/[0.03] px-5 py-4 last:border-0 md:grid-cols-[110px_1fr]">
                <div className="font-mono text-amber-400" dir="ltr">{t}</div>
                <div>
                  <div className="font-bold text-stone-100">{n}</div>
                  <div className="text-sm leading-7 text-stone-400">{d}</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 leading-8 text-stone-300">
          <h2 className="mb-3 text-2xl font-bold text-amber-200">نکات صادقانه دربارهٔ کیفیت و ساخت</h2>
          <ul className="list-disc space-y-2 pr-5 text-sm">
            <li>این ویدیو در محیط بدون GPU و با رندر برنامه‌نویسی‌شده (Python/NumPy) ساخته شده است؛ سبک، موشن‌گرافیک سینمایی و المان‌محور با نورپردازی، بلوم، دانهٔ فیلم و حرکت دوربین است، نه رندر سه‌بعدی واقع‌گرای هم‌سطح بلیزارد. برای آن سطح باید همین دکوپاژ و صدا را به Blender/Unreal یا ابزار تصویرساز هوش مصنوعی بسپارید.</li>
            <li>رعایت‌ها: زن‌ها با روسری (بدون موی باز)، مردها بدون کراوات، فضای ایران (روستای ساحل خلیج فارس، مزرعه، حیاط خانهٔ قدیمی، کوه).</li>
            <li>صدای استاد: بندهای S12، S14، S15 و S16 از فایل‌های صوتی j3-3، j3-2، p1 و p2 همان مخزن بریده شده‌اند. نقطهٔ برش را با تشخیص گفتار خودکار پیدا کردم و خودم گوش نکرده‌ام؛ لطفاً شنیده و در صورت نیاز جابه‌جا کنید.</li>
            <li>صدای S13 (پیام صوتی «توضیح به هوش ۲») پیدا نشد؛ متن همان بخش را راوی فارسی خواند. زیرنویس بندهای استاد از متن کتاب است و ممکن است با کلمات دقیق گفتار اندکی فرق کند.</li>
            <li>موسیقی و افکت‌ها (پد، نی، دف، گام شور، باد، باران، قدم، آسانسور و...) همه ساخته‌شدهٔ برنامه‌ای‌اند. تلاوت قرآن استفاده نشده و آیه‌ها فقط به‌صورت تایپ‌شده نمایش داده می‌شوند.</li>
            <li>سکانس S16 در دقیقهٔ ۴۰ (۱:۳۰ از ۲:۳۰) قطع می‌شود؛ ادامه (سفرهٔ شام و آیهٔ ابراهیم ۷) باید در قطعهٔ بعدی بیاید. سکانس S12 هم از ۱:۰۰ خودش شروع شده، چون دقیقهٔ ۳۰ وسط آن است.</li>
          </ul>
        </section>
      </main>
      <footer className="border-t border-white/5 py-8 text-center text-xs text-stone-600">بازیِ بزرگ · نسخهٔ کارگاهی</footer>
    </div>
  )
}
